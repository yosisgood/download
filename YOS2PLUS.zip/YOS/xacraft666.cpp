#include<iostream>
#include<fstream> 
#include<windows.h>
#include<cstdio>
#include<cstring>
#include<stdio.h>
#include<conio.h>
#include<sstream>
#include<time.h>
#include<vector> 
#include<stdio.h>
#include<stdlib.h>
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000) ? 1:0) 
using namespace std;
bool allowsave=1;
bool jiandang[21];//�����浵 
string nam,pas;

void full_screen()
{   
    HWND hwnd = GetForegroundWindow();
    int cx = GetSystemMetrics(SM_CXSCREEN);           
    int cy = GetSystemMetrics(SM_CYSCREEN);            

    LONG l_WinStyle = GetWindowLong(hwnd,GWL_STYLE);   
    
    SetWindowLong(hwnd,GWL_STYLE,(l_WinStyle | WS_POPUP | WS_MAXIMIZE) & ~WS_CAPTION & ~WS_THICKFRAME & ~WS_BORDER);

    SetWindowPos(hwnd, HWND_TOP, 0, 0, cx, cy, 0);
}

void init() {
	int cx = GetSystemMetrics(SM_CXSCREEN);           
    int cy = GetSystemMetrics(SM_CYSCREEN);            

	SetWindowPos(GetConsoleWindow(), HWND_TOPMOST, 0, 0, cx, cy, SWP_NOSIZE);
	DWORD mode;
	GetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), &mode);
 	mode &= ~ENABLE_QUICK_EDIT_MODE;
	SetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), mode);
	SetWindowLong(GetConsoleWindow(), GWL_STYLE, GetWindowLong(GetConsoleWindow(), GWL_STYLE) & ~WS_CAPTION);
}
void console()
{
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);  
    CONSOLE_SCREEN_BUFFER_INFO bInfo; 
    GetConsoleScreenBufferInfo(hOut, &bInfo );  
    SetConsoleTitle("XACRAFT 3.3 �������İ�"); // ���ô��ڵı���
}
struct han{
    int ui,num;
}hand[21][50],rl[51];
struct pflist{
    int num;
    han k[101];
    han sum;
}lis[10001],rlis[10001];
struct blocklist{
    string nam,ape;
    int pps,cor,hylink,maxl,mintim;
}bl[10001];
struct Eclist{
    string ecs,nam,notice;
    int jb,lin,emc;
}eclis[10001];
string xapas,xanam,xapin;
char ch;
int errortimes=0;
string pfd="XZ";//Ƥ�� 
long long jb=100;//������� 
int a[21][5][256][2049],x[21]={0},y[21],jie[21],cx[21],cy[21],ran[21],mode[21],xuanze=0,lisn,rlisn,rln,eclisn,emc;
int smz[21],jed[21];
int days[21],tims[21],chuancan,chuandang;
int i,j,kkk;
bool kn=0,echave[10001];
char cmmd;
string comd;
int seed;
bool bpf[51];
string pfs[10]={"XZ","XA","GD","MC","�d","��","��","��","��","��"};
string waitingnotice[100]={
    "XACRAFT 1.0�汾������2021��2��12��",
    "XACRAFT�ոյ���ʱ����������������150�У�",
    "��ƻ�������ɸ��ʽ�Ϊ0.05%",
    "��ᷢ�֣����е�XACRAFT����Ⱥϵ����ֲ�����ɣ�",
    "����XACRAFT���������齻��XACRAFT����Ϸ���ɣ�",
    "��Ҫ���������ƣ�",
    "����ģʽ�У�����L�����ɲ鿴״̬����",
    "����ֵС��30ʱ������ֵ������ָ���",
    "���ռ�һЩƻ���������Ų��ᰤ����",
    "��ʯ��ʯ��������߸߶�Ϊ16��"
};
int pfp[10]={0,50,50,100,150,150,150,150,150,300},sehao=240,pfn=10;
int shop[21][21]=
{
    { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,17,17,17,0,0,0,11,27,11,0,0,0,18,18,18,0,0,1 },
    { 1,0,0,17,6,17,0,0,0,11,27,11,0,0,0,18,15,18,0,0,1 },
    { 1,0,0,17,17,17,0,0,0,11,27,11,0,0,0,18,18,18,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,11,11,11,11,11,11,11,11,11,27,11,11,11,11,11,11,11,11,11,1 },
    { 1,27,27,27,27,27,27,27,27,27,7,27,27,27,27,27,27,27,27,27,1 },
    { 1,11,11,11,11,11,11,11,11,11,27,11,11,11,11,11,11,11,11,11,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,29,29,29,0,0,0,11,27,11,0,0,0,13,13,13,0,0,1 },
    { 1,0,0,29,28,29,0,0,0,11,27,11,0,0,0,13,14,13,0,0,1 },
    { 1,0,0,29,29,29,0,0,0,11,27,11,0,0,0,13,13,13,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,0,0,0,0,0,0,0,0,11,27,11,0,0,0,0,0,0,0,0,1 },
    { 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 },
};
void color(int corcorcor){
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),corcorcor);
}
bool kd(char ccc){
    if(!KEY_DOWN(ccc)) return 0;
    else return 1;
}
int rdm(int aaaaa,int bbbbb){
    return rand()%(bbbbb-aaaaa+1)+aaaaa;
}
void cls(){//�S�̵��ṩ��������Ȩ����ϵɾ����    
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD coordScreen = { 0, 0 };    // home for the cursor
    SetConsoleCursorPosition( hConsole, coordScreen );
}
char gl(){
    if(kd('Q')) return 'Q';
    if(kd('W')) return 'W';
    if(kd('E')) return 'E';
    if(kd('R')) return 'R';
    if(kd('T')) return 'T';
    if(kd('Y')) return 'Y';
    if(kd('U')) return 'U';
    if(kd('I')) return 'I';
    if(kd('O')) return 'O';
    if(kd('P')) return 'P';
    if(kd('A')) return 'A';
    if(kd('S')) return 'S';
    if(kd('D')) return 'D';
    if(kd('F')) return 'F';
    if(kd('G')) return 'G';
    if(kd('H')) return 'H';
    if(kd('J')) return 'J';
    if(kd('K')) return 'K';
    if(kd('L')) return 'L';
    if(kd('Z')) return 'Z';
    if(kd('X')) return 'X';
    if(kd('C')) return 'C';
    if(kd('V')) return 'V';
    if(kd('B')) return 'B';
    if(kd('N')) return 'N';
    if(kd('M')) return 'M';
    if(kd('1')) return '1';
    if(kd('2')) return '2';
    if(kd('3')) return '3';
    if(kd('4')) return '4';
    if(kd('5')) return '5';
    if(kd('6')) return '6';
    if(kd('7')) return '7';
    if(kd('8')) return '8';
    if(kd('9')) return '9';
    if(kd('0')) return '0';
}
string XAPin(string s){//�ú���������������ϵɳ�˰� 
    int sn=min((int)s.size()+64,90),kn=(int)s.size();
    int pin[256];
    string sp;
    for(int i=0;i<s.size()-1;i++){
        pin[i]=(int)(s[i]+s[i+1])/2;
    }
    for(int i=0;i<s.size();i++){
        if(kn%2==(int)pin[i]%3) sp+=(char)(min((int)sn+i*2,127));
        sp+=(char)pin[i];
    }
    return sp;
}
string getTime(){//�ú���������������ϵɳ�˰� 
    time_t timep;
    time (&timep);
    char tmp[64];
    strftime(tmp, sizeof(tmp), "%m%d",localtime(&timep) );
    return tmp;
}
string GetTime(){//�ú���������������ϵɳ�˰� 
    time_t timep;
    time (&timep);
    char tmp[64];
    strftime(tmp, sizeof(tmp), "%Y%m%d",localtime(&timep) );
    return tmp;
}
int change_num(string will_change){//�ú���������������ϵɳ�˰� 
    stringstream sin;
    sin<<will_change;
    int change_ok;
    sin>>change_ok;
    return change_ok;
}
string change_string(int will_change){//�ú���������������ϵɳ�˰� 
    stringstream sin;
    sin<<will_change;
    string change_ok;
    sin>>change_ok;
    return change_ok;
}
void rightLine(string str){//�ú���������������ϵɳ�˰� 
    int i,l,w;
    w=80;
    l=str.length();
    for(i=1;i<80-l;i++)
    cout<<" ";
    cout<<str<<endl;
    return ;
}
void Line(string str){//�ú���������������ϵɳ�˰� 
    int i,l,w;
    w=80;
    l=str.length();
    for(i=0;i<(w-l)/2;i++)
    cout<<" ";
    cout<<str<<endl;
    return ;
}
void line(string str){//�ú���������������ϵɳ�˰� 
    int i,l,w;
    w=80;
    l=str.length();
    for(i=0;i<(w-l)/2;i++)
    cout<<" ";
    cout<<str;
    return ;
}
void jjsc(string str,int cor){//�ú���������������ϵɳ�˰� 
    system("cls");
    color(cor);
    system("cls");
    for(i=1;i<=11;i++) cout<<endl;
    color(cor);
    Line(str);
    color(7);
}
void del(int ccc,int uiui,int numm){
    for(i=1;i<=50;i++){
        if(uiui==hand[ccc][i].ui){
            hand[ccc][i].num-=numm;
            if(hand[ccc][i].num<=0){
                hand[ccc][i].num=0;
                hand[ccc][i].ui=0;
            }
            return ;
        }
    }
}
void pus(int ccc,int uiui,int numm){
    for(i=1;i<=50;i++){
        if(uiui==hand[ccc][i].ui && hand[ccc][i].num+numm<=bl[hand[ccc][i].ui].maxl){
            hand[ccc][i].num+=numm;
            return ;
        }
    }
    for(i=1;i<=50;i++){
        if(hand[ccc][i].ui==0){
            hand[ccc][i].ui=uiui;
            hand[ccc][i].num=numm;
            return ;
        }
    }
}
void waiting(string notice){
    system("cls");
    color(15);
    system("cls");
    cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
    Line(notice);
    cout<<endl<<endl<<endl;
    Line("��֪����");
    cout<<endl;
    srand(time(NULL));
    Line(waitingnotice[rand()%10]);
}
void HideCursor1(){
    HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO CursorInfo;
    GetConsoleCursorInfo(handle, &CursorInfo);//��ȡ����̨�����Ϣ
    CursorInfo.bVisible = false; //���ؿ���̨���
    SetConsoleCursorInfo(handle, &CursorInfo);//���ÿ���̨���״̬
}
//�߼������֣�ʼ��
bool end_day(){
    string tmp=GetTime(),temp="20230901";
    if(tmp>=temp) return 1;
    else return 0;
}
bool fool_days(){
    string tmp=getTime();
    if(tmp=="0401") return 1;
    else return 0;
}
bool vote_days(){
    string tmp=GetTime();
    if(tmp>="20230121" && tmp<="20230131") return 1;
    else return 0;
}
bool vote_days_before(){
    string tmp=GetTime();
    if(tmp>="20230101" && tmp<="20230120") return 1;
    else return 0;
}
//�߼������֣��գ� 
//XA�˻� 
void lin(string str){//�ú���������������ϵɳ�˰� 
    int i,l,w;
    w=80;
    l=str.length();
    for(i=0;i<(w-l)/2;i++)
    cout<<" ";
    cout<<str;
    return ;
}
void nameline(string str){
    int i,l,w;
    w=50;
    l=str.length();
    for(i=0;i<(w-l)/2-1;i++)
    cout<<" ";
    cout<<str;
    if((w-l)%2==0){
        for(i=0;i<(w-l)/2-1;i++)
        cout<<" ";
    }else{
        for(i=0;i<(w-l)/2;i++)
        cout<<" ";
    }
    color(7);
    cout<<"|";
    return ;
}
void passline(string str){
    int i,l,w;
    w=50;
    l=str.length();
    for(i=0;i<(w-l)/2-1;i++)
    cout<<" ";
    for(i=0;i<str.length();i++) cout<<"*";
    if((w-l)%2==0){
        for(i=0;i<(w-l)/2-1;i++)
        cout<<" ";
    }else{
        for(i=0;i<(w-l)/2;i++)
        cout<<" ";
    }
    color(7);
    cout<<"|";
    return ;
}
bool Login_getpass(){
    errortimes=0;
    cp:;
    if(errortimes>=3){
        color(13);
        cout<<endl;
        lin("����������࣬��¼ʧ�ܣ�");
        Sleep(3000);
        color(7);
        return 0;
    }
    xapin="";
    ch=0;
    while(ch!=13){
        system("cls");
        color(14);
        cout<<endl;
        lin("��¼ XA �˺�");
        printf("\n\n\n\n\n\n");
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |";
        color(11);
        nameline("��ӭ������"+xanam);
        cout<<endl;
        lin("==================================================");
        printf("\n\n\n");
        color(10);
        cout<<"               >>��������";
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |";
        passline(xapin);
        cout<<endl;
        lin("==================================================");
        ch=_getch();
        xapin+=ch;
        if(ch==8){
            xapin=xapin.substr(0,xapin.length()-1);
            xapin=xapin.substr(0,xapin.length()-1);
        }
    }
    stringstream in1,in2;
    xapin=XAPin(xapin);
    in1<<xapin;
    in1>>xapin;
    in2<<xapas;
    in2<<xapas;
    if(xapin!=xapas){
        cout<<endl;
        color(12);
        lin("�������");
        errortimes++;
        Sleep(1500);
        goto cp;
    }
    system("cls");
    return 1;
} 
void getnam(){
    xapin="";
    ch=0;
    while(ch!=13){
        system("cls");
        color(14);
        cout<<endl;
        lin("ע�� XA �˺�");
        printf("\n\n\n\n\n\n");
        color(10);
        cout<<"               >>�û���";
        color(15);
        cout<<"  {������}"; 
        if(xapin.length()>45){
            color(12);
            cout<<"   �û�������";
            xapin=xapin.substr(0,xapin.length()-1);
        }
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |";
        nameline(xapin);
        cout<<endl;
        lin("==================================================");
        printf("\n\n\n");
        color(10);
        cout<<"               >>����";
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |                                                |";
        cout<<endl;
        lin("==================================================");
        ch=_getch();
        xapin+=ch;
        if(ch==8){
            xapin=xapin.substr(0,xapin.length()-1);
            xapin=xapin.substr(0,xapin.length()-1);
        }
    }
    system("cls");
    stringstream in1;
    in1<<xapin;
    in1>>xanam;
    if(xanam.length()==0) getnam();
    return ;
}
void getpas(){
    xapin="";
    ch=0;
    while(ch!=13){
        system("cls");
        color(14);
        cout<<endl;
        lin("ע�� XA �˺�");
        printf("\n\n\n\n\n\n");
        color(10);
        cout<<"               >>�û��� ������� ��";
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |";
        nameline(xanam);
        cout<<endl;
        lin("==================================================");
        printf("\n\n\n");
        color(10);
        cout<<"               >>����";
        color(15);
        cout<<"  {������}"; 
        if(xapin.length()>45){
            color(12);
            cout<<"   �������";
            xapin=xapin.substr(0,xapin.length()-1);
        }
        color(7);
        cout<<endl;
        lin("==================================================");
        cout<<endl;
        cout<<"               |";
        passline(xapin);
        cout<<endl;
        lin("==================================================");
        ch=_getch();
        xapin+=ch;
        if(ch==8){
            xapin=xapin.substr(0,xapin.length()-1);
            xapin=xapin.substr(0,xapin.length()-1);
        }
    }
    system("cls");
    xapas=xapin;
    if(xapas.length()==0) getpas();
    return ;
}
void XAlogin(){
    ifstream fin("XA�˻�.xadata");
    fin>>xanam>>xapas;
    fin.close();
    if(xanam.length()!=0 && xapas.length()!=0){
        if(Login_getpass()==0){
            i=0;
            cout<<0/i;
        }
        return ;
    } 
    getnam();
    getpas();   
    ofstream fout("XA�˻�.xadata");
    fout<<xanam<<endl<<XAPin(xapas);
    fout.close();
    return ;    
}
//XA�˻� 
void xsyd(){
    bool flag=1;
    while(flag){
        system("cls");
        for(i=1;i<=8;i++) cout<<endl;
        color(10);
        Line("���ã���ӭ������XACRAFT 3.3��Ϊ�˱�֤����������Ϸ���飬��������ʵ���������ѡ��"); 
        cout<<endl;
        color(15);
        Line("A.�ҵ�һ�νӴ�XACRAFT/��XACRAFT����Ϸ���򡢲�����������Ϥ");
        Line("B.���Ѿ��Ӵ�������������XACRAFT,���ǵ�һ������XACRAFT 3.3");
        Line("C.                  ����XACRAFT 3.3�����               .");
        cmmd=getch();
        if(cmmd=='A' || cmmd=='a'){
            while(cmmd!='W' && cmmd!='w'){
                system("cls");
                for(i=1;i<=8;i++) cout<<endl;
                color(15);
                Line("�����Ƽ����Ķ���XACRAFT 3.3���������ֲᡷ");
                cout<<endl;
                Line("��Q�����ֲ�     ��W�������Ķ�");
                color(14);
                cout<<endl;
                Line("�뱣֤�������˻������������޷����ֲ�");
                color(15);
                Line("�����δ�������Ķ����ֲᣬ�����ڱ��⻭���ڰ���""J""���Դ򿪰���");
                cmmd=getch();
                if(cmmd=='Q' || cmmd=='q'){
                    system("start https://docs.qq.com/doc/DWEJ6dkRnZmR3bmZM");
                }   
            }
            flag=0;
        }   
        if(cmmd=='B' || cmmd=='b'){
            while(cmmd!='W' && cmmd!='w'){
                system("cls");
                for(i=1;i<=8;i++) cout<<endl;
                color(15);
                Line("�����Ƽ����Ķ���XACRAFT 3.3�°汾ʹ���ֲᡷ");
                cout<<endl;
                Line("��Q�����ֲ�     ��W�������Ķ�");
                color(14);
                cout<<endl;
                Line("�뱣֤�������˻������������޷����ֲ�");
                color(15);
                Line("�����δ�������Ķ����ֲᣬ�����ڱ��⻭���ڰ���""J""���Դ򿪰���");
                cmmd=getch();
                if(cmmd=='Q' || cmmd=='q'){
                    system("start https://docs.qq.com/doc/DWGlueHRhb01iTEF5");
                }   
            }
            flag=0;
        }
        if(cmmd=='C' || cmmd=='c'){
            while(cmmd!='W' && cmmd!='w'){
                system("cls");
                for(i=1;i<=8;i++) cout<<endl;
                color(15);
                Line("��ӭ���ص�XACRAFT 3.3��");
                cout<<endl;
                Line("��W�������Ķ�");
                color(15);
                cmmd=getch();   
            }
            flag=0;
        }
    }
}
void sav(){
    if(allowsave){
    waiting("���ڱ����������ݣ������ĵȴ�");
    ofstream fout("XACRAFT�浵�ļ�.xadata");
    fout<<1<<endl;
    for(i=1;i<=20;i++) fout<<jiandang[i]<<" ";
    fout<<endl;
    for(i=1;i<=20;i++){
        for(j=1;j<=49;j++){
            fout<<hand[i][j].ui<<" "<<hand[i][j].num<<" ";
        }
        fout<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<mode[i]<<" ";
    }
    fout<<endl;
    fout<<pfd<<endl;
    fout<<jb<<" "<<emc<<endl;
    for(i=1;i<=20;i++){
        fout<<x[i]<<" "<<y[i]<<" "<<jie[i]<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<smz[i]<<" "<<jed[i]<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<ran[i]<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<days[i]<<" "<<tims[i]<<endl;
    }
    for(i=1;i<=50;i++){
        fout<<bpf[i]<<endl;
    }
    fout<<sehao<<endl;
    for(int iii=1;iii<=20;iii++){
        for(int jjj=1;jjj<=2;jjj++){
            for(int kkk=1;kkk<=255;kkk++){
                for(int lll=1;lll<=2048;lll++){
                    fout<<a[iii][jjj][kkk][lll]<<" ";
                }
                fout<<endl;
            }
        }
    }
    fout.close();
    }
}
void rea(){
    if(allowsave){
    waiting("���ڶ�ȡ�������ݣ������ĵȴ�");
    ifstream fin("XACRAFT�浵�ļ�.xadata");
    fin>>i;
    for(i=1;i<=20;i++) fin>>jiandang[i];
    for(i=1;i<=20;i++){
        for(j=1;j<=49;j++){
            fin>>hand[i][j].ui>>hand[i][j].num;
        }
    }
    for(i=1;i<=20;i++){
        fin>>mode[i];
    }
    fin>>pfd;
    fin>>jb>>emc;
    for(i=1;i<=20;i++){
        fin>>x[i]>>y[i]>>jie[i];
    }
    for(i=1;i<=20;i++){
        fin>>smz[i]>>jed[i];
    }
    for(i=1;i<=20;i++){
        fin>>ran[i];
    }
    for(i=1;i<=20;i++){
        fin>>days[i]>>tims[i];
    }
    for(i=1;i<=50;i++){
        fin>>bpf[i];
    }
    fin>>sehao;
    for(int iii=1;iii<=20;iii++){
        for(int jjj=1;jjj<=2;jjj++){
            for(int kkk=1;kkk<=255;kkk++){
                for(int lll=1;lll<=2048;lll++){
                    fin>>a[iii][jjj][kkk][lll];
                }
            }
        }
    }
    fin.close();    
    }
}
void checkcun(){
    if(allowsave){
    ifstream fin("XACRAFT�浵�ļ�.xadata");
    fin>>i;
    fin.close();
    if(i!=0) return ;
    ofstream fout("XACRAFT�浵�ļ�.xadata");
    xsyd();
    waiting("��⵽��һ�ε�¼�������½��浵");
    fout<<1<<endl;
    for(i=1;i<=20;i++) fout<<0<<" ";
    fout<<endl;
    for(i=1;i<=20;i++){
        for(j=1;j<=49;j++){
            fout<<0<<" "<<0<<" ";
        }
        fout<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<0<<" ";
    }
    fout<<endl;
    fout<<"XZ"<<endl;
    fout<<100<<" "<<0<<endl;
    for(i=1;i<=20;i++){
        fout<<0<<" "<<0<<" "<<0<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<0<<" "<<0<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<0<<endl;
    }
    for(i=1;i<=20;i++){
        fout<<0<<" "<<0<<endl;
    }
    fout<<1<<endl;
    for(i=2;i<=50;i++){
        fout<<0<<endl;
    }
    fout<<240<<endl;
    for(int iii=1;iii<=20;iii++){
        for(int jjj=1;jjj<=2;jjj++){
            for(int kkk=1;kkk<=255;kkk++){
                for(int lll=1;lll<=2048;lll++){
                    fout<<0<<" ";
                }
                fout<<endl;
            }
        }
    }
    fout.close();
    return ;
    }
}
void ppf(int cor){
    color(cor);
    cout<<pfd;
    color(7);
}
void Logical_Lock(){//�ú���������������ϵɳ�˰� 
    /*if(fool_days()){
        system("cls");
        color(252);
        system("cls");
        cout<<endl;
        Line("��ϲ��");
        cout<<endl<<endl;
        color(240);
        Line("������˺�����������һ��룺AprilFoolDay");
        cmmd=getch();
    }*/
    if(end_day()){
        system("cls");
        color(252);
        system("cls");
        cout<<endl;
        Line("XACRAFT �汾����");
        cout<<endl<<endl;
        color(240);
        Line("������ʹ�õ�XACRAFT 3.3����2023��9��1�չ��ڣ�����������°汾��");
        cout<<endl;
        Line("������£��밴Q���Դ򿪸�������"); 
        Line("https://www.luogu.com.cn/blog/XAscience/replace");
        cmmd=getch();
        if(cmmd=='Q' or cmmd=='q') system("start https://www.luogu.com.cn/blog/XAscience/replace");
        int fk=0;
        cout<<fk/fk;
    }
    if(vote_days()){
        while(cmmd!='O' && cmmd!='o' && cmmd!='Q' && cmmd!='q'){
            system("cls");
            color(252);
            system("cls");
            cout<<endl;
            Line("XACRAFT 3.5��������ͶƱ���ڽ���");
            cout<<endl<<endl;
            color(240);
            Line("XACRAFT 3.5��������ͶƱ���ڽ��У���ӭ����XACRAFT 3.5��������ͶƱ��");
            cout<<endl;
            Line("������룬�밴Q���Դ�ͶƱ���ӡ�����O��������"); 
            Line("https://tp.wjx.top/vm/Yr8JZBA.aspx# ");
            cmmd=getch();
            if(cmmd=='Q' or cmmd=='q') system("start https://tp.wjx.top/vm/Yr8JZBA.aspx# ");
        }
    }
    if(vote_days_before()){
        while(cmmd!='O' && cmmd!='o' && cmmd!='Q' && cmmd!='q'){
            system("cls");
            color(252);
            system("cls");
            cout<<endl;
            Line("XACRAFT 3.5��������ͶƱ������ʼ");
            cout<<endl<<endl;
            color(240);
            Line("XACRAFT 3.5��������ͶƱ����2023��1��21�տ�ʼ����ӭ����XACRAFT 3.5��������ͶƱ��");
            cout<<endl;
            Line("����鿴���밴Q���Դ�ͶƱ���ӡ�����O��������"); 
            Line("https://tp.wjx.top/vm/Yr8JZBA.aspx# ");
            cmmd=getch();
            if(cmmd=='Q' or cmmd=='q') system("start https://tp.wjx.top/vm/Yr8JZBA.aspx# ");
        }
    }
    return ;
}
void centerlink(int cor){
    if(bl[cor].hylink==1){
        if(jie[chuandang]==1){
            color(chuancan+bl[cor].cor);
            cout<<bl[cor].ape;  
        }else if(jie[chuandang]==2){
            color(207);
            cout<<bl[cor].ape;
        }else if(chuandang==0){
            color(255);
            cout<<bl[cor].ape;  
        }
    }
    if(bl[cor].hylink==2){
        if(jie[chuandang]==1){
            color(bl[cor].cor);
            cout<<bl[cor].ape;
        }else if(chuandang==0){
            color(bl[cor].cor);
            cout<<bl[cor].ape;
        }else{
            color(bl[cor].cor-64);
            cout<<bl[cor].ape;
        }
    }
}
string wri(int cor){
    return bl[cor].nam;
}
int print(int cor){
    if(bl[cor].hylink!=0) centerlink(cor);
    else{
        color(bl[cor].cor);
        cout<<bl[cor].ape;  
    }
}
void lists(){
    //bl[].ape="",bl[].cor=,bl[].nam="",bl[].pps=,bl[].hylink=,bl[].maxl=,bl[].mintim=;
    bl[0].ape="  ",bl[0].cor=0,bl[0].nam="��������",bl[0].pps=0,bl[0].hylink=1,bl[0].maxl=32767,bl[0].mintim=0;
    bl[1].ape="  ",bl[1].cor=170,bl[1].nam="�ݷ���",bl[1].pps=0,bl[1].hylink=0,bl[1].maxl=64,bl[1].mintim=500;
    bl[2].ape="  ",bl[2].cor=34,bl[2].nam="��Ҷ",bl[2].pps=0,bl[2].hylink=0,bl[2].maxl=64,bl[2].mintim=200;
    bl[3].ape="  ",bl[3].cor=136,bl[3].nam="ʯͷ",bl[3].pps=0,bl[3].hylink=0,bl[3].maxl=64,bl[3].mintim=2000;
    bl[4].ape="  ",bl[4].cor=102,bl[4].nam="����",bl[4].pps=0,bl[4].hylink=0,bl[4].maxl=64,bl[4].mintim=500;
    bl[5].ape="",bl[5].cor=0,bl[5].nam="",bl[5].pps=0,bl[5].hylink=0,bl[5].maxl=0,bl[5].mintim=0;
    bl[6].ape="WO",bl[6].cor=96,bl[6].nam="��ľԭľ",bl[6].pps=0,bl[6].hylink=0,bl[6].maxl=64,bl[6].mintim=1000;
    bl[7].ape="::",bl[7].cor=139,bl[7].nam="��ʯ��ʯ",bl[7].pps=0,bl[7].hylink=2,bl[7].maxl=64,bl[7].mintim=2500;
    bl[8].ape="::",bl[8].cor=142,bl[8].nam="�ƽ��ʯ",bl[8].pps=0,bl[8].hylink=2,bl[8].maxl=64,bl[8].mintim=2500;
    bl[9].ape="AP",bl[9].cor=207,bl[9].nam="ƻ��",bl[9].pps=1,bl[9].hylink=0,bl[9].maxl=16,bl[9].mintim=200;
    bl[10].ape="GA",bl[10].cor=239,bl[10].nam="��ƻ��",bl[10].pps=1,bl[10].hylink=0,bl[10].maxl=1,bl[10].mintim=200;
    bl[11].ape="  ",bl[11].cor=238,bl[11].nam="ɳ��",bl[11].pps=0,bl[11].hylink=0,bl[11].maxl=64,bl[11].mintim=500;
    bl[12].ape="==",bl[12].cor=239,bl[12].nam="ɰ��",bl[12].pps=0,bl[12].hylink=0,bl[12].maxl=64,bl[12].mintim=2000;
    bl[13].ape="##",bl[13].cor=127,bl[13].nam="ѩ��",bl[13].pps=0,bl[13].hylink=0,bl[13].maxl=64,bl[13].mintim=500;
    bl[14].ape="::",bl[14].cor=32,bl[14].nam="������",bl[14].pps=0,bl[14].hylink=0,bl[14].maxl=64,bl[14].mintim=200;
    bl[15].ape="BR",bl[15].cor=112,bl[15].nam="����ԭľ",bl[15].pps=0,bl[15].hylink=0,bl[15].maxl=64,bl[15].mintim=1000;
    bl[16].ape="HW",bl[16].cor=31,bl[16].nam="HelloWorld",bl[16].pps=0,bl[16].hylink=0,bl[16].maxl=1,bl[16].mintim=0;
    bl[17].ape="==",bl[17].cor=96,bl[17].nam="��ľľ��",bl[17].pps=0,bl[17].hylink=0,bl[17].maxl=64,bl[17].mintim=1000;
    bl[18].ape="==",bl[18].cor=126,bl[18].nam="����ľ��",bl[18].pps=0,bl[18].hylink=0,bl[18].maxl=64,bl[18].mintim=1000;
    bl[19].ape="//",bl[19].cor=6,bl[19].nam="ľ����",bl[19].pps=1,bl[19].hylink=1,bl[19].maxl=64,bl[19].mintim=200;
    bl[20].ape="##",bl[20].cor=128,bl[20].nam="��¯",bl[20].pps=0,bl[20].hylink=0,bl[20].maxl=64,bl[20].mintim=500;
    bl[21].ape="::",bl[21].cor=128,bl[21].nam="ú��ʯ",bl[21].pps=0,bl[21].hylink=2,bl[21].maxl=64,bl[21].mintim=2500;
    bl[22].ape="�z",bl[22].cor=0,bl[22].nam="ú̿",bl[22].pps=1,bl[22].hylink=1,bl[22].maxl=64,bl[22].mintim=0;
    bl[23].ape="�z",bl[23].cor=14,bl[23].nam="��",bl[23].pps=1,bl[23].hylink=1,bl[23].maxl=64,bl[23].mintim=0;
    bl[24].ape="�z",bl[24].cor=11,bl[24].nam="��ʯ",bl[24].pps=1,bl[24].hylink=1,bl[24].maxl=64,bl[24].mintim=0;
    bl[25].ape="��",bl[25].cor=15,bl[25].nam="ú̿��",bl[25].pps=0,bl[25].hylink=0,bl[25].maxl=64,bl[25].mintim=2000;
    bl[26].ape="��",bl[26].cor=239,bl[26].nam="���",bl[26].pps=0,bl[26].hylink=0,bl[26].maxl=64,bl[26].mintim=3000;
    bl[27].ape="��",bl[27].cor=191,bl[27].nam="��ʯ��",bl[27].pps=0,bl[27].hylink=0,bl[27].maxl=64,bl[27].mintim=5000;
    bl[28].ape="SP",bl[28].cor=96,bl[28].nam="��ɼԭľ",bl[28].pps=0,bl[28].hylink=0,bl[28].maxl=64,bl[28].mintim=1000;
    bl[29].ape="--",bl[29].cor=96,bl[29].nam="��ɼľ��",bl[29].pps=0,bl[29].hylink=0,bl[29].maxl=64,bl[29].mintim=1000;
    bl[30].ape="  ",bl[30].cor=68,bl[30].nam="�½���",bl[30].pps=0,bl[30].hylink=0,bl[30].maxl=64,bl[30].mintim=2000;
    bl[31].ape="��",bl[31].cor=76,bl[31].nam="�½紫����",bl[31].pps=1,bl[31].hylink=0,bl[31].maxl=1,bl[31].mintim=0;
    bl[32].ape="��",bl[32].cor=236,bl[32].nam="���Һ���",bl[32].pps=0,bl[32].hylink=0,bl[32].maxl=64,bl[32].mintim=5000;
    bl[33].ape="##",bl[33].cor=110,bl[33].nam="өʯ",bl[33].pps=0,bl[33].hylink=0,bl[33].maxl=64,bl[33].mintim=5000;
    bl[34].ape="��",bl[34].cor=154,bl[34].nam="�����紫����",bl[34].pps=1,bl[34].hylink=0,bl[34].maxl=1,bl[34].mintim=0;
    bpf[0]=1;
    lisn=16,rlisn=3,rln=8,eclisn=14;
    //lis[x].num=a,lis[x].k[y].num=a,lis[x].k[y].ui=a,lis[x].sum.num=a,lis[x].sum.ui=a;
    lis[0].num=2,lis[0].k[1].num=1,lis[0].k[1].ui=1,lis[0].k[2].num=1,lis[0].k[2].ui=2,lis[0].sum.num=1,lis[0].sum.ui=16;
    lis[1].num=1,lis[1].k[1].num=1,lis[1].k[1].ui=6,lis[1].sum.num=4,lis[1].sum.ui=17;
    lis[2].num=1,lis[2].k[1].num=1,lis[2].k[1].ui=15,lis[2].sum.num=4,lis[2].sum.ui=18;
    lis[3].num=1,lis[3].k[1].num=2,lis[3].k[1].ui=17,lis[3].sum.num=4,lis[3].sum.ui=19;
    lis[4].num=1,lis[4].k[1].num=2,lis[4].k[1].ui=18,lis[4].sum.num=4,lis[4].sum.ui=19;
    lis[5].num=1,lis[5].k[1].num=8,lis[5].k[1].ui=3,lis[5].sum.num=1,lis[5].sum.ui=20;
    lis[6].num=1,lis[6].k[1].num=9,lis[6].k[1].ui=22,lis[6].sum.num=1,lis[6].sum.ui=25;
    lis[7].num=1,lis[7].k[1].num=1,lis[7].k[1].ui=25,lis[7].sum.num=9,lis[7].sum.ui=22;
    lis[8].num=1,lis[8].k[1].num=9,lis[8].k[1].ui=23,lis[8].sum.num=1,lis[8].sum.ui=26;
    lis[9].num=1,lis[9].k[1].num=1,lis[9].k[1].ui=26,lis[9].sum.num=9,lis[9].sum.ui=23;
    lis[10].num=1,lis[10].k[1].num=9,lis[10].k[1].ui=24,lis[10].sum.num=1,lis[10].sum.ui=27;
    lis[11].num=1,lis[11].k[1].num=1,lis[11].k[1].ui=27,lis[11].sum.num=9,lis[11].sum.ui=24;
    lis[12].num=2,lis[12].k[1].num=8,lis[12].k[1].ui=23,lis[12].k[2].num=1,lis[12].k[2].ui=9,lis[12].sum.num=1,lis[12].sum.ui=10;
    lis[13].num=1,lis[13].k[1].num=1,lis[13].k[1].ui=28,lis[13].sum.num=4,lis[13].sum.ui=29;
    lis[14].num=1,lis[14].k[1].num=2,lis[14].k[1].ui=29,lis[14].sum.num=4,lis[14].sum.ui=19;
    lis[15].num=3,lis[15].k[1].num=5,lis[15].k[1].ui=22,lis[15].k[2].num=2,lis[15].k[2].ui=23,lis[15].k[3].num=1,lis[15].k[3].ui=24,lis[15].sum.num=1,lis[15].sum.ui=31;
    lis[16].num=2,lis[16].k[1].num=40,lis[16].k[1].ui=32,lis[16].k[2].num=40,lis[16].k[2].ui=33,lis[16].sum.num=1,lis[16].sum.ui=34;
    //rlis[x].num=1,rlis[x].k[1].num=1,rlis[x].k[1].ui=a,rlis[x].sum.num=1,rlis[x].sum.ui=a;
    rlis[1].num=1,rlis[1].k[1].num=1,rlis[1].k[1].ui=21,rlis[1].sum.num=1,rlis[1].sum.ui=22;
    rlis[2].num=1,rlis[2].k[1].num=1,rlis[2].k[1].ui=8,rlis[2].sum.num=1,rlis[2].sum.ui=23;
    rlis[3].num=1,rlis[3].k[1].num=1,rlis[3].k[1].ui=7,rlis[3].sum.num=1,rlis[3].sum.ui=24;
    //rl[x].num=a,rl[x].ui=a;
    rl[1].num=4,rl[1].ui=6;
    rl[2].num=4,rl[2].ui=15;
    rl[3].num=2,rl[3].ui=17;
    rl[4].num=2,rl[4].ui=18;
    rl[5].num=1,rl[5].ui=19;
    rl[6].num=8,rl[6].ui=22;
    rl[7].num=4,rl[7].ui=28;
    rl[8].num=2,rl[8].ui=29;
    //eclis[1].ecs="",eclis[1].nam="",eclis[1].notice,eclis[1].jb=,eclis[].emc=,eclis[1].lin=0;
    eclis[1].ecs="LTBJICMYPUmsnjfbmplrHt",eclis[1].nam="XACRAFTһ���������",eclis[1].notice="XACRAFTһ�꣬һ·������飡",eclis[1].jb=100,eclis[1].emc=100,eclis[1].lin=0;
    eclis[2].ecs="FJUXeUPq\\\\",eclis[2].nam="CIL 2021-Win һ����",eclis[2].notice="��л����CILϵ�����µ�֧�֣�",eclis[2].jb=20,eclis[2].emc=10,eclis[2].lin=0;
    eclis[3].ecs="FJU[\\IPqZf\\",eclis[3].nam="CIL 2021-Win ������",eclis[3].notice="��л����CILϵ�����µ�֧�֣�",eclis[3].jb=50,eclis[3].emc=30,eclis[3].lin=0;
    eclis[4].ecs="FJUR[RVNmb\\",eclis[4].nam="CIL 2021-Win ������",eclis[4].notice="��л����CILϵ�����µ�֧�֣�",eclis[4].jb=80,eclis[4].emc=50,eclis[4].lin=0;
    eclis[5].ecs="FJUXeVVTkR\\",eclis[5].nam="CIL 2021-Win �ļ���",eclis[5].notice="��л����CILϵ�����µ�֧�֣�",eclis[5].jb=100,eclis[5].emc=80,eclis[5].lin=0;
    eclis[6].ecs="FJUYRcTTVWqZ`\\",eclis[6].nam="CIL 2021-Win �弶��",eclis[6].notice="��л����CILϵ�����µ�֧�֣�",eclis[6].jb=150,eclis[6].emc=100,eclis[6].lin=0;
    eclis[7].ecs="MLRLPTNPMZ0\\",eclis[7].nam="HSE һ�Ƚ���",eclis[7].notice="��л����HSEϵ�����µ�֧�֣�",eclis[7].jb=60,eclis[7].lin=0;
    eclis[8].ecs="MLRPKRQOVQS4\\",eclis[8].nam="HSE ���Ƚ���",eclis[8].notice="��л����HSEϵ�����µ�֧�֣�",eclis[8].jb=30,eclis[8].lin=0;
    eclis[9].ecs="MLRPHSRLXN2\\",eclis[9].nam="HSE ���Ƚ���",eclis[9].notice="��л����HSEϵ�����µ�֧�֣�",eclis[9].jb=10,eclis[9].lin=0;
    eclis[10].ecs="OOSLPTNPMZ0\\",eclis[10].nam="FXGF--FS һ�Ƚ���",eclis[10].notice="��л����FXGF--FSϵ�����µ�֧�֣�",eclis[10].jb=80,eclis[10].lin=0;
    eclis[11].ecs="OOSPKRQOVQS4\\",eclis[11].nam="FXGF--FS ���Ƚ���",eclis[11].notice="��л����FXGF--FSϵ�����µ�֧�֣�",eclis[11].jb=50,eclis[11].lin=0;
    eclis[12].ecs="OOSPHSRLXN2\\",eclis[12].nam="FXGF--FS ���Ƚ���",eclis[12].notice="��л����FXGF--FSϵ�����µ�֧�֣�",eclis[12].jb=30,eclis[12].lin=0;
    eclis[13].ecs="apVrXuZlPXqmjYhZjomXRm ",eclis[13].nam="���˽ڲ���",eclis[13].notice="�ǳ���Ǹ���˽ڲʵ������������ʧ����˫���黹��",eclis[13].jb=20,eclis[13].emc=20,eclis[13].lin=0;
    eclis[14].ecs="XqmjYVZXomXRmb",eclis[14].nam="���˽ڴ����",eclis[14].notice="��ϲ����ϲ�����ⲻ���⣿",eclis[14].jb=-10,eclis[14].emc=-10,eclis[14].lin=0;
    eclis[1].ecs="LTBJICMYPUmsnjfbmplrH ",eclis[1].nam="XACRAFT�����������",eclis[1].notice="XACRAFT�����꣬һ·������飡",eclis[1].jb=150,eclis[1].emc=150,eclis[1].lin=0;
    //�����Լ�����\\����C++���ַ����б�ʾ��\���� 
    return ;
}
void print_packback(int com,int xuanz){
    color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=1;i<=9;i++){
            if(hand[com][i].num!=0){
                print(hand[com][i].ui);
            }else{
                cout<<"��";
            }
            color(7);
            printf(" ");
        }
        color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=1;i<=9;i++){
            if(i==xuanz) color(11);
            else color(7);
            if(hand[com][i].num!=0){
                if(hand[com][i].num<=64) printf("%02d",hand[com][i].num);
                else if(hand[com][i].num<100) cout<<hand[com][i].num%100/10<<"+";
                else if(hand[com][i].num<1000) cout<<hand[com][i].num%1000/100<<"*";
                else cout<<hand[com][i].num%10000/1000<<"^";
            }else{
                cout<<"--";
            }
            color(7);
            printf(" ");
        }
        color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=10;i<=18;i++){
            color(7);
            if(hand[com][i].num!=0){
                print(hand[com][i].ui);
            }else{
                cout<<"��";
            }
            color(7);
            printf(" ");
        }
        color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=10;i<=18;i++){
            if(i==xuanz) color(11);
            else color(7);
            if(hand[com][i].num!=0){
                if(hand[com][i].num<=64) printf("%02d",hand[com][i].num);
                else if(hand[com][i].num<100) cout<<hand[com][i].num%100/10<<"+";
                else if(hand[com][i].num<1000) cout<<hand[com][i].num%1000/100<<"*";
                else cout<<hand[com][i].num%10000/1000<<"^";
            }else{
                cout<<"--";
            }
            color(7);
            printf(" ");
        }
        color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=19;i<=27;i++){
            color(7);
            if(hand[com][i].num!=0){
                print(hand[com][i].ui);
            }else{
                cout<<"��";
            }
            color(7);
            printf(" ");
        }
        color(7);
        cout<<endl<<"\t\t\t   ";
        for(i=19;i<=27;i++){
            if(i==xuanz) color(11);
            else color(7);
            if(hand[com][i].num!=0){
                if(hand[com][i].num<=64) printf("%02d",hand[com][i].num);
                else if(hand[com][i].num<100) cout<<hand[com][i].num%100/10<<"+";
                else if(hand[com][i].num<1000) cout<<hand[com][i].num%1000/100<<"*";
                else cout<<hand[com][i].num%10000/1000<<"^";
            }else{
                cout<<"--";
            }
            color(7);
            printf(" ");
        }
}
bool che(int ccc,int uiui,int numm){
    for(int oooo=1;oooo<=50;oooo++){
        if(uiui==hand[ccc][oooo].ui && (hand[ccc][oooo].num<numm || hand[ccc][oooo].num==0)){
            return false;
        }
    }
    for(int oooo=1;oooo<=50;oooo++){
        if(uiui==hand[ccc][oooo].ui){
            return true;
        }
    }
    return false;
}
bool jian(int ccc,int cho){
    bool flag=true;
    for(int oo=1;oo<=lis[cho].num;oo++){
        flag=(che(ccc,lis[cho].k[oo].ui,lis[cho].k[oo].num) && flag);
        if(!flag) break;
    }
    return flag;
}
void craftingtable(int com){
    for(int oo=1;oo<=50;oo++){
        if(hand[com][oo].num==0){
            hand[com][oo].num=0;
            hand[com][oo].ui=0;
        }
    }
    int xuanz=1;
    while(cmmd!='E' && cmmd!='e'){  
        cmmd='?';
        system("cls");
        color(14);
        Line("����̨");
        print_packback(com,-1);
        cout<<endl;
        Line("W/S-�л�     Q-�ϳ�     E-�˳�");
        color(10);
        Line(wri(lis[xuanz].sum.ui));
        color(7);
        for(i=max(xuanz-8,1);i<=min(lisn,xuanz+8);i++){
            if(i==xuanz) cout<<"   > ";
            else cout<<"     ";
            if(jian(com,i)){
                color(10);
                cout<<" ��  ";
            }else{
                color(12);
                cout<<" ��  ";
            }
            print(lis[i].sum.ui);
            color(7);
            cout<<"*";
            printf("%02d",lis[i].sum.num);
            color(7);
            cout<<" = ";
            print(lis[i].k[1].ui);
            color(7);
            cout<<"*";
            printf("%02d",lis[i].k[1].num);
            for(j=2;j<=lis[i].num;j++){
                color(7);
                cout<<"+";
                print(lis[i].k[j].ui);
                color(7);
                cout<<"*";
                printf("%02d",lis[i].k[j].num); 
            }
            cout<<endl;
        }
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w'){
            xuanz--;
        }
        if(cmmd=='S' || cmmd=='s'){
            xuanz++;
        }
        if(xuanz<=0 || xuanz>lisn) xuanz=1;
        if(cmmd=='Q' || cmmd=='q'){
            if(jian(com,xuanz)){
                for(j=1;j<=lis[xuanz].num;j++){
                    del(com,lis[xuanz].k[j].ui,lis[xuanz].k[j].num);
                }
                pus(com,lis[xuanz].sum.ui,lis[xuanz].sum.num);
            }
        }
    }
    cmmd='?';
    return ;
}
bool rjian(int ccc,int cho){
    bool flag=true;
    for(int oo=1;oo<=rlis[cho].num;oo++){
        flag=(che(ccc,rlis[cho].k[oo].ui,rlis[cho].k[oo].num) && flag);
        if(!flag) break;
    }
    return flag;
}
void furnace(int com){
    cmmd='?';
    for(int oo=1;oo<=50;oo++){
        if(hand[com][oo].num==0){
            hand[com][oo].num=0;
            hand[com][oo].ui=0;
        }
    }
    int xuanz=1;
    while(cmmd!='E' && cmmd!='e'){  
        cmmd='?';
        system("cls");
        color(14);
        Line("��¯");
        print_packback(com,-1);
        cout<<endl;
        Line("W/S-�л�     Q-ұ��     R-����ȼ��     E-�˳�");
        cout<<"           ȼ��:"<<ran[com]<<endl;
        color(10);
        Line(wri(rlis[xuanz].sum.ui));
        color(7);
        for(i=max(xuanz-8,1);i<=min(rlisn,xuanz+8);i++){
            if(i==xuanz) cout<<"   > ";
            else cout<<"     ";
            if(rjian(com,i)){
                if(ran[com]==0){
                    color(14);
                    cout<<" ��  "; 
                }else{
                    color(10);
                    cout<<" ��  ";   
                }
            }else{
                color(12);
                cout<<" ��  ";
            }
            print(rlis[i].sum.ui);
            color(7);
            cout<<"*";
            printf("%02d",rlis[i].sum.num);
            color(7);
            cout<<" = ";
            print(rlis[i].k[1].ui);
            color(7);
            cout<<"*";
            printf("%02d",rlis[i].k[1].num);
            for(j=2;j<=rlis[i].num;j++){
                color(7);
                cout<<"+";
                print(rlis[i].k[j].ui);
                color(7);
                cout<<"*";
                printf("%02d",rlis[i].k[j].num);    
            }
            cout<<endl;
        }
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w'){
            xuanz--;
        }
        if(cmmd=='S' || cmmd=='s'){
            xuanz++;
        }
        if(cmmd=='R' || cmmd=='r'){
            int xuanze=1;
            while(cmmd!='E' && cmmd!='e'){
                system("cls");
                color(14);
                Line("����ȼ��");
                print_packback(com,-1);
                cout<<endl;
                Line("W/S-�л�     Q-����     E-�˳�");
                color(7);
                cout<<"          ȼ��:"<<wri(rl[xuanze].ui)<<endl;
                for(i=max(xuanze-8,1);i<=min(rln,xuanze+8);i++){
                    if(i==xuanze) cout<<"   > ";
                    else cout<<"     ";
                    if(che(com,rl[i].ui,1)){
                        color(10);
                        cout<<" ��  ";   
                    }else{
                        color(12);
                        cout<<" ��  ";
                    }
                    print(rl[i].ui);
                    color(7);
                    cout<<endl;
                }
                cmmd=getch();
                if(cmmd=='W' || cmmd=='w'){
                    xuanze--;
                }
                if(cmmd=='S' || cmmd=='s'){
                    xuanze++;
                }
                if(xuanze<=0 || xuanze>rln) xuanze=1;
                if(cmmd=='Q' || cmmd=='q'){
                    if(che(com,rl[xuanze].ui,1)){
                        del(com,rl[xuanze].ui,1);
                        ran[com]+=rl[xuanze].num;
                    }
                }
            }
            cmmd='?';
        }
        if(xuanz<=0 || xuanz>rlisn) xuanz=1;
        if(cmmd=='Q' || cmmd=='q'){
            if(rjian(com,xuanz) && ran[com]>=1){
                ran[com]--;
                for(j=1;j<=rlis[xuanz].num;j++){
                    del(com,rlis[xuanz].k[j].ui,rlis[xuanz].k[j].num);
                }
                pus(com,rlis[xuanz].sum.ui,rlis[xuanz].sum.num);
            }
        }
    }
    cmmd='?';
    return ;
}
void packback(int com){
    while(kd('E')){
    }
    cmmd='?';
    while(cmmd!='E' && cmmd!='e'){
        cmmd=getch();
    }
    int xuanz=xuanze;
    cmmd='?';
    while(cmmd!='E' && cmmd!='e'){  
        cmmd='?';
        system("cls");
        color(14);
        Line("����");
        print_packback(com,xuanz);
        cout<<endl;
        Line(" G-����   H-�ϳ�   E-�˳�");
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w'){
            if(xuanz<=9) xuanz+=18;
            else xuanz-=9;
        }
        if(cmmd=='A' || cmmd=='a'){
            if(xuanz%9==1) xuanz+=8;
            else xuanz-=1;
        }
        if(cmmd=='S' || cmmd=='s'){
            if(xuanz>=19) xuanz-=18;
            else xuanz+=9;
        }
        if(cmmd=='D' || cmmd=='d'){
            if(xuanz%9==0) xuanz-=8;
            else xuanz+=1;
        }
        if(cmmd=='G' || cmmd=='g'){
            int xuz1=1,xuz2=1;
            while(cmmd!='P' && cmmd!='p'){  
                system("cls");
                color(14);
                Line("ѡ������Ҫ��������Ʒ1 (Q-ȷ��  P-�˳�)");
                print_packback(com,xuz1);
                cmmd=getch();
                if(cmmd=='W' || cmmd=='w'){
                    if(xuz1<=9) xuz1+=18;
                    else xuz1-=9;
                }
                if(cmmd=='A' || cmmd=='a'){
                    if(xuz1%9==1) xuz1+=8;
                    else xuz1-=1;
                }
                if(cmmd=='S' || cmmd=='s'){
                    if(xuz1>=19) xuz1-=18;
                    else xuz1+=9;
                }
                if(cmmd=='D' || cmmd=='d'){
                    if(xuz1%9==0) xuz1-=8;
                    else xuz1+=1;
                }
                if(cmmd=='Q' || cmmd=='q') break;
            }
            while(cmmd!='P' && cmmd!='p'){  
                system("cls");
                color(14);
                Line("ѡ������Ҫ��������Ʒ2 (Q-ȷ��  P-�˳�)");
                print_packback(com,xuz2);
                cmmd=getch();
                if(cmmd=='W' || cmmd=='w'){
                    if(xuz2<=9) xuz2+=18;
                    else xuz2-=9;
                }
                if(cmmd=='A' || cmmd=='a'){
                    if(xuz2%9==1) xuz2+=8;
                    else xuz2-=1;
                }
                if(cmmd=='S' || cmmd=='s'){
                    if(xuz2>=19) xuz2-=18;
                    else xuz2+=9;
                }
                if(cmmd=='D' || cmmd=='d'){
                    if(xuz2%9==0) xuz2-=8;
                    else xuz2+=1;
                }
                if(cmmd=='Q' || cmmd=='q') break;
            }
            if(cmmd!='P' && cmmd!='p'){
                int aaa=hand[com][xuz1].num,bbb=hand[com][xuz1].ui;
                hand[com][xuz1].num=hand[com][xuz2].num;
                hand[com][xuz1].ui=hand[com][xuz2].ui;
                hand[com][xuz2].num=aaa;
                hand[com][xuz2].ui=bbb;
            }
        }
        if(cmmd=='H' || cmmd=='h') craftingtable(com);
        //if(cmmd=='J' || cmmd=='j') furnace(com);
    }
    cmmd='?';
    for(int oo=1;oo<=50;oo++){
        if(hand[com][oo].num==0){
            hand[com][oo].num=0;
            hand[com][oo].ui=0;
        }
    }
    return ;
}
void handand(int ccc,int xxx){
    if(bl[hand[ccc][xxx].ui].maxl==hand[ccc][xxx].num){
        for(i=1;i<=50;i++){
            if(hand[ccc][i].num<bl[hand[ccc][xxx].ui].maxl && hand[ccc][xxx].ui==hand[ccc][i].ui){
                hand[ccc][i].num++;
                return ;
            }
        }
        for(i=1;i<=50;i++){
            if(hand[ccc][i].ui==0){
                hand[ccc][i].ui=hand[ccc][xxx].ui;
                hand[ccc][i].num++;
                return ;
            }
        }
    }else{
        hand[ccc][xxx].num++;
    }
}
void pt(int ccc,int jjj,int xxx,int yyy,bool dq){
    if(!dq){//na
        if(a[ccc][jjj][xxx][yyy]!=0){
            //Sleep(bl[a[ccc][jjj][xxx][yyy]].mintim);
            if(mode[ccc]==1){
                int timew=0;
                while(kd('Y') || kd('U') || kd('I') || kd('H') || kd('K') || kd('B') || kd('N') || kd('M')){
                    //cout<<timew;
                    timew++;
                    Sleep(1);
                    if(timew*100>=bl[a[ccc][jjj][xxx][yyy]].mintim) break;
                }
                if(timew*100<bl[a[ccc][jjj][xxx][yyy]].mintim) return ; 
            }
            for(i=1;i<=50;i++){
                if(a[ccc][jjj][xxx][yyy]==hand[ccc][i].ui){
                    handand(ccc,i);
                    a[ccc][jjj][xxx][yyy]=0;
                    return ;
                }
            }
            for(i=1;i<=50;i++){
                if(hand[ccc][i].ui==0){
                    hand[ccc][i].ui=a[ccc][jjj][xxx][yyy];
                    handand(ccc,i);
                    a[ccc][jjj][xxx][yyy]=0;
                    return ;
                }
            }
        }
        return ;
    }else if(dq){//fang
        if(a[ccc][jjj][xxx][yyy]==0 && hand[ccc][xuanze].num!=0 && bl[hand[ccc][xuanze].ui].pps==0){
            a[ccc][jjj][xxx][yyy]=hand[ccc][xuanze].ui;
            hand[ccc][xuanze].num--;
            if(hand[ccc][xuanze].num==0){
                hand[ccc][xuanze].ui=0;
            }
        }
        if(a[ccc][jjj][xxx][yyy]==20) furnace(ccc);
        return ;
    }
    dq='2';
}
void LoginXZ(){
    char c;
    Log:
    system("cls");
    color(14);
    Line("��¼XZ�˺� --- Login XZ");
    cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
    color(7);
    Line("L-��¼     M-�˳�");
    cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
    color(10); 
    Line("û���˺ţ� R-ע��");
    color(7);
    c=getch();
    system("cls");
    if(c=='L' || c=='l'){
        ifstream fin("XZ�˻�.xzdata");
        fin>>nam>>pas;
        fin.close();
        color(14);
        Line("��������");
        color(12);
        Line("�û�����"+nam);
        color(7);
        string pass1;
        int i=0;
        char ch;
        while ((ch=_getch())!=13)
        {
            pass1+=ch;
            cout<<"*";
        }
        if(pass1!=pas){
            system("cls");
            Line("��Ǹ������������������µ�¼��(�����Ӻ󷵻�)");
            goto Log;
        }
        return ;
    }
    else if(c=='R' || c=='r'){
        color(14);
        Line("ע��XZ�˺� --- Register XZ");
        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
        color(7);
        Line("G-ע��һ��XZ�˺�   H-��ȡ�����ݵ������˺�");
        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
        color(10); 
        Line("�����˺ţ� M-��¼");
        color(7);
        c=getch();
        if(c=='M' || c=='m'){
            goto Log;
        }
        else if(c=='H' || c=='h'){
            system("cls");
            color(14);
            Line("��ȡXZ�˺� --- Read XZ");
            color(7);
            Line("ʹ����ʾ:�뽫���߽����ġ��浵.txt���ļ����Ƶ���������ļ���Ŀ¼��"); 
            cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
            Line("G-��ȡ�浵");
            cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
            color(10); 
            Line("�����˺ţ� M-��¼");
            color(7);
            c=getch();
            if(c=='M' || c=='m'){
                goto Log;
            }else if(c=='G' || c=='g'){
                ifstream fin("�浵.txt");
                int lllll;
                fin>>lllll;
                fin>>lllll;
                fin>>nam;
                fin>>lllll;
                fin>>nam;
                fin.close();
                string s1,s2;
                system("cls");
                color(14);
                Line("��������");
                color(7);
                cin>>s1;
                system("cls");
                color(14);
                Line("������һ������");
                color(7);
                cin>>s2;
                if(s1!=s2){
                    system("cls");
                    Line("��Ǹ�������������������ע�ᣡ(�����Ӻ󷵻�)");
                    goto Log;
                }
                pas=s1;
                return ;
            }else goto Log;
        } 
        else if(c=='G' || c=='g'){
            system("cls");
            color(14);
            Line("�����û���");
            color(7);
            cin>>nam;
            string s1,s2;
            system("cls");
            color(14);
            Line("��������");
            color(7);
            cin>>s1;
            system("cls");
            color(14);
            Line("������һ������");
            color(7);
            cin>>s2;
            if(s1!=s2){
                system("cls");
                Line("��Ǹ�������������������ע�ᣡ(�����Ӻ󷵻�)");
                goto Log;
            }
            pas=s1;
            return ;
        }
        else goto Log;
    }else if(c=='M' || c=='m'){
        goto Logok;
    }
    else goto Log;
    Logok:;
}
void XZLogin(){
    color(7);
    LoginXZ();
    ofstream fout("XZ�˻�.xzdata");
    fout<<nam<<endl<<pas;
    fout.close();
    return ;
}
void buybf(){
    int xuanz=0;
    while(cmmd!='M' && cmmd!='m'){
        system("cls");
        color(12);
        Line("����Ƥ��");
        color(7);
        cout<<"                  ���н��:"<<jb<<"��"<<endl;
        for(int i=0;i<pfn;i++){
            cout<<"                  ";
            if(bpf[i]){
                color(10);
                cout<<"��ӵ��";
            }else{
                color(12);
                cout<<"δӵ��";
            }
            color(7);
            if(xuanz==i) cout<<"    > ";
            else cout<<"      ";
            cout<<pfs[i]<<" : "<<pfp[i];
            cout<<endl;
        }
        Line("W/S-�л�   E-ѡ��   M-�˳�");
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w') xuanz--;
        if(cmmd=='S' || cmmd=='s') xuanz++;
        if(cmmd=='E' || cmmd=='e'){
            if(bpf[xuanz]==1) pfd=pfs[xuanz];
            else if(jb>=pfp[xuanz]){
                jb=jb-pfp[xuanz];
                bpf[xuanz]=1;
                pfd=pfs[xuanz];
            }
        }
        if(xuanz>=pfn) xuanz=0;
    }
}
void buycor(){
    int xuanz=0;
    while(cmmd!='M' && cmmd!='m'){
        system("cls");
        color(12);
        Line("�л���ɫ");
        color(7);
        for(int i=max(0,xuanz-10);i<=min(255,xuanz+10);i++){
            cout<<"                                 ";
            color(7);
            if(xuanz==i) cout<<"    > ";
            else cout<<"      ";
            ppf(i);
            cout<<endl;
        }
        color(7); 
        Line("W/S-�л�   E-ѡ��   M-�˳�");
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w') xuanz--;
        if(cmmd=='S' || cmmd=='s') xuanz++;
        if(cmmd=='E' || cmmd=='e'){
            sehao=xuanz;
        }
        if(xuanz>=256) xuanz=0;
    }
}
void shang(){//����������̳� 
    system("cls");
    color(7);
    system("cls");
    chuancan=0;
    chuandang=0;
    int xxx=10,yyy=10;
    while(!(xxx==16 && yyy==16)){
        system("cls");
        for(i=0;i<21;i++){
            cout<<"                   ";
            color(7);
            for(j=0;j<21;j++){
                if(i==xxx && j==yyy){
                    ppf(sehao);
                }else print(shop[i][j]);
            }
            color(7);
            cout<<endl;
        }
        cout<<"   ���н��:"<<jb<<"��"<<"     "<<"WASD-�ƶ�  վ��ͼ�������ϼ��ɴ�������";
        cout<<endl<<"                 ";
        print(6);
        color(7);
        cout<<" - �л�Ƥ��";
        cout<<"                     ";
        print(15);
        color(7);
        cout<<" - �л���ɫ";
        cout<<endl<<"                 ";
        print(28);
        color(7);
        cout<<" - �����ڴ�";
        cout<<"                     ";
        print(14);
        color(7);
        cout<<" - �˳��̳�";
        cmmd=getch();
        if(cmmd=='W' || cmmd=='w') xxx--;
        if(cmmd=='A' || cmmd=='a') yyy--;
        if(cmmd=='S' || cmmd=='s') xxx++;
        if(cmmd=='D' || cmmd=='d') yyy++;
        if(xxx<=0) xxx=1;
        if(xxx>=20) xxx=19;
        if(yyy<=0) yyy=1;
        if(yyy>=20) yyy=19;
        if(xxx==4 && yyy==4){
            buybf();
            xxx=10;
            yyy=10;
        }
        if(xxx==4 && yyy==16){
            buycor();
            xxx=10;
            yyy=10;
        }
        if(xxx==16 && yyy==4){
            xxx=10;
            yyy=10;
            //system("start https://www.luogu.com.cn/chat?uid=541826");
        }
    }
}
bool checks(string s1,string s2){
    int num=0;
    for(int p=0;p<s2.size();p++){
        if(s1[p]!=s2[p]) num++;
    }
    if(num<=1 && s2.size()>1) return 1;
    return 0;
}
void Exchange_code(){
    system("cls");
    color(240);
    system("cls");
    Line("�һ���");
    cout<<endl<<endl<<endl<<endl<<endl;
    Line("��������Ķһ���");
    cout<<endl<<"           ";
    cin>>comd;
    int tot=0;
    for(i=1;i<=eclisn;i++){
        if(checks(eclis[i].ecs,XAPin(comd))){
            tot=i;
            if(echave[i]==1) tot=-2;
            echave[i]=1;
            break;
        }else if(checks(eclis[i].ecs,comd)){
            tot=-1;
            break;
        }
    }
    system("cls");
    color(240);
    system("cls");
    if(tot>0){
        Line("�һ��ɹ�");
        cout<<endl<<endl<<endl<<endl<<endl<<endl;
        Line("���һ�������"+eclis[tot].nam);
        cout<<endl;
        Line("�������"+change_string(eclis[tot].jb)+"���");
        cout<<endl;
        if(eclis[tot].emc!=0){
            Line("�������"+change_string(eclis[tot].emc)+"����");
            cout<<endl;
        }
        color(252);
        Line(eclis[tot].notice);
        cout<<endl;
        color(240);
        jb+=eclis[tot].jb;
        emc+=eclis[tot].emc;
    }else if(tot==-1){
        Line("�һ�ʧ��");
        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
        color(252);
        Line("    XACRAFT��⵽�����Բ鿴�����Ի�ȡ�һ��룬ϣ�������ճ�����Ϸ�������ܹ��淶�Լ�����Ϸ��Ϊ��������Ϸ��");
        cout<<endl<<endl<<endl;
        color(240);
    }else if(tot==-2){
        Line("�һ�ʧ��");
        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
        color(252);
        Line("�öһ����ѱ��һ���");
        cout<<endl<<endl<<endl;
        color(240);
    }else{
        Line("�һ�ʧ��");
        cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
        color(252);
        Line("δ���ҵ��һ���");
        cout<<endl<<endl<<endl;
        color(240);
    }
    Line("[��������˳�]");
    cmmd=getch();
    cmmd='?';
    return ;
}
void mycenter(){
    while(!(cmmd=='e' || cmmd=='E')){
        system("cls");
        color(240);
        system("cls");
        Line("��������");
        cout<<endl<<endl<<endl<<endl;
        color(240);
        if(xanam.empty()) Line("XA�˺ţ�δ��¼");
        else Line("XA�˺ţ��ѵ�¼��"+xanam+"��");
        cout<<endl;
        Line("����ֵ��"+change_string(emc));
        Line("�ȼ���Lv."+change_string((emc/50)+1));
        cout<<endl;
        Line("G-�����̳�");
        cout<<endl;
        Line("H-�� �� ��");
        cout<<endl;
        Line("E-�˳���������");
        cmmd=getch();
        if(cmmd=='G' || cmmd=='g') shang();
        if(cmmd=='H' || cmmd=='h') Exchange_code();
    }
    cmmd='?';
}
void printt(int com){
    int wq=10;
    cout<<"                  "; 
    color(12);
    for(i=1;i<=10;i++){
        if(smz[com]>=i*10) cout<<"��",wq--;
    }
    if(smz[com]%10==1) cout<<"��",wq--;
    else if(smz[com]%10==2) cout<<"��",wq--;
    else if(smz[com]%10==3) cout<<"��",wq--;
    else if(smz[com]%10==4 || smz[com]%10==5 || smz[com]%10==6) cout<<"��",wq--;
    else if(smz[com]%10==7) cout<<"��",wq--;
    else if(smz[com]%10==8) cout<<"��",wq--;
    else if(smz[com]%10==9) cout<<"��",wq--;
    for(i=1;i<=wq;i++) cout<<"  "; 
    cout<<"    "; 
    color(6);
    for(i=1;i<=10;i++){
        if(jed[com]>=i*10) cout<<"��";
    }
    if(jed[com]%10==1) cout<<"��";
    else if(jed[com]%10==2) cout<<"��";
    else if(jed[com]%10==3) cout<<"��";
    else if(jed[com]%10==4 || jed[com]%10==5 || jed[com]%10==6) cout<<"��";
    else if(jed[com]%10==7) cout<<"��";
    else if(jed[com]%10==8) cout<<"��";
    else if(jed[com]%10==9) cout<<"��";
    cout<<"                ";
}
int nw(int com){
    smz[com]=100;
    jed[com]=100;
    jie[com]=1;
    jiandang[com]=true; 
    //1 ���� 
    for(i=0;i<=2047;i++){
        for(j=1;j<=255;j++){
            a[com][1][j][i]=0;
        }
    }
    for(i=1;i<=50;i++){
        hand[com][i].ui=0;
        hand[com][i].num=0;
    } 
    int ke=0;
    system("cls");
    color(252);
    system("cls");
    Line("�ҵĴ浵");
    color(240);
    Line("�µ�����"); 
    cout<<endl<<endl;
    line("ѡ��ģʽ��1:����ģʽ  2:����ģʽ��: ");
    cin>>mode[com];
    cout<<endl;
    line("��������: ");
    cin>>comd;
    seed=change_num(comd);
    comd="?";
    srand((unsigned)seed);
    y[com]=1024;
    int top=0,tot=rdm(40,60); 
    for(i=0;i<2048;i++){
        if(i==1024){
            x[com]=tot; 
            do{
                ++x[com];
            }while(a[com][1][x[com]][top]!=0);
            x[com]+=3;
            cx[com]=x[com];
            cy[com]=y[com];
        }
                a[com][1][tot+1][top]=3;
                a[com][1][tot+1][top-3]=3;
                a[com][1][tot+1][top-2]=3;
                a[com][1][tot+1][top-1]=3;
                a[com][1][tot+1][top+1]=3;
                a[com][1][tot+1][top+2]=3;
                a[com][1][tot+1][top+3]=3;
                a[com][1][tot+2][top-3]=3;
                a[com][1][tot+2][top-2]=3;
                a[com][1][tot+2][top]=3;
                a[com][1][tot+2][top-1]=3;
                a[com][1][tot+2][top+1]=3;
                a[com][1][tot+2][top+2]=3;
                a[com][1][tot+2][top+3]=3;
                a[com][1][tot+3][top-2]=3;
                a[com][1][tot+3][top]=3;
                a[com][1][tot+3][top-1]=3;
                a[com][1][tot+3][top+1]=3;
                a[com][1][tot+3][top+2]=3;
                a[com][1][tot+4][top]=3;
                a[com][1][tot+4][top-1]=3;
                a[com][1][tot+4][top+1]=3;
        for(j=tot;j>=0;j--){
            a[com][1][j][top]=3;
        }
        for(j=tot;j>=0;j--){
            a[com][2][j][top]=30;
        }
        top++;
        int u=rdm(0,10);
        if(u>=9) tot++;
        if(u<=1) tot--;
        if(tot>=256)tot=255;
        if(tot<10) tot=10;
        int uu=rdm(0,8);
    /*  if((uu==6 && i>4 && i<2045 && i!=1023 && i!=1024 && i!=1025 && ke+1<top && seed!=1234567890)||(seed==123456789)){
            ke=top;
            a[com][1][tot+1][top]=6;
            a[com][1][tot+2][top]=6;
            a[com][1][tot+3][top]=6;
            int uuu=rdm(0,3);
            if(uuu==1){
                a[com][1][tot+4][top]=6;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+5][top+3]=2;
                a[com][1][tot+6][top-2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
                a[com][1][tot+6][top+2]=2;
                a[com][1][tot+7][top]=2;
                a[com][1][tot+7][top-1]=2;
                a[com][1][tot+7][top+1]=2;
            }else{
                a[com][1][tot+3][top-3]=2;
                a[com][1][tot+3][top-2]=2;
                a[com][1][tot+3][top-1]=2;
                a[com][1][tot+3][top+1]=2;
                a[com][1][tot+3][top+2]=2;
                a[com][1][tot+3][top+3]=2;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
            }
        }*/
    }
    //2  ��ϵ
    int u=rdm(1,100),pl=0;
    for(i=1;i<=2048;i++){
        int tot;
        for(j=256;j>=0;j--){
            if(a[com][1][j][i]==3){
                tot=j;
                break;
            }
        }
        if(u<=30){
            a[com][1][tot][i]=1;
            a[com][1][tot-1][i]=4;
            a[com][1][tot-2][i]=4;
            a[com][1][tot-3][i]=4;
            int uu=rdm(0,8);
            if((uu==6 && i>4 && i<2045 && i!=1023 && i!=1024 && i!=1025 && pl<i && seed!=1234567890)||(seed==123456789)){
                top=i;
                pl=i+1;
            a[com][1][tot+1][top]=6;
            a[com][1][tot+2][top]=6;
            a[com][1][tot+3][top]=6;
            int uuu=rdm(0,3);
            if(uuu==1){
                a[com][1][tot+4][top]=6;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+5][top+3]=2;
                a[com][1][tot+6][top-2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
                a[com][1][tot+6][top+2]=2;
                a[com][1][tot+7][top]=2;
                a[com][1][tot+7][top-1]=2;
                a[com][1][tot+7][top+1]=2;
            }else{
                a[com][1][tot+3][top-3]=2;
                a[com][1][tot+3][top-2]=2;
                a[com][1][tot+3][top-1]=2;
                a[com][1][tot+3][top+1]=2;
                a[com][1][tot+3][top+2]=2;
                a[com][1][tot+3][top+3]=2;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
            }
        }
        }
        else if(u<=50){
            a[com][1][tot][i]=11;
            a[com][1][tot-1][i]=11;
            a[com][1][tot-2][i]=11;
            a[com][1][tot-3][i]=12;
            int uu=rdm(0,8);
            if((uu==6 && i>4 && i<2045 && i!=1023 && i!=1024 && i!=1025 && pl<i && seed!=1234567890)||(seed==123456789)){
                top=i;
                pl=i+1;
                int uuu=rdm(0,3);
                if(uuu==1){
                    a[com][1][tot+1][top]=14;
                    a[com][1][tot+2][top]=14;
                    a[com][1][tot+3][top]=14;
                    a[com][1][tot+4][top]=14;
                }else{
                    a[com][1][tot+1][top]=14;
                    a[com][1][tot+2][top]=14;
                    a[com][1][tot+3][top]=14;
                }
            }
        }else if(u<=80){
            a[com][1][tot][i]=1;
            a[com][1][tot-1][i]=4;
            a[com][1][tot-2][i]=4;
            a[com][1][tot-3][i]=4;
            int uu=rdm(0,8);
            if((uu==6 && i>4 && i<2045 && i!=1023 && i!=1024 && i!=1025 && pl<i && seed!=1234567890)||(seed==123456789)){
                top=i;
                pl=i+1;
            a[com][1][tot+1][top]=15;
            a[com][1][tot+2][top]=15;
            a[com][1][tot+3][top]=15;
            int uuu=rdm(0,3);
            if(uuu==1){
                a[com][1][tot+4][top]=15;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+5][top+3]=2;
                a[com][1][tot+6][top-2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
                a[com][1][tot+6][top+2]=2;
                a[com][1][tot+7][top]=2;
                a[com][1][tot+7][top-1]=2;
                a[com][1][tot+7][top+1]=2;
            }else{
                a[com][1][tot+3][top-3]=2;
                a[com][1][tot+3][top-2]=2;
                a[com][1][tot+3][top-1]=2;
                a[com][1][tot+3][top+1]=2;
                a[com][1][tot+3][top+2]=2;
                a[com][1][tot+3][top+3]=2;
                a[com][1][tot+4][top-3]=2;
                a[com][1][tot+4][top-2]=2;
                a[com][1][tot+4][top]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+4][top+2]=2;
                a[com][1][tot+4][top+3]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
            }
        }
        }else{
            a[com][1][tot][i]=13;
            a[com][1][tot-1][i]=4;
            a[com][1][tot-2][i]=4;
            a[com][1][tot-3][i]=4;
            int uu=rdm(0,15);
            if((uu==6 && i>4 && i<2045 && i!=1023 && i!=1024 && i!=1025 && pl<i && seed!=1234567890)||(seed==123456789)){
                top=i;
                pl=i+1;
            a[com][1][tot+1][top]=28;
            a[com][1][tot+2][top]=28;
            a[com][1][tot+3][top]=28;
            int uuu=rdm(0,3);
            if(uuu==1){
                a[com][1][tot+4][top]=28;
                a[com][1][tot+5][top]=28;
                a[com][1][tot+6][top]=28;
                a[com][1][tot+7][top]=28;
                a[com][1][tot+3][top-3]=2;
                a[com][1][tot+3][top-2]=2;
                a[com][1][tot+3][top-1]=2;
                a[com][1][tot+3][top+3]=2;
                a[com][1][tot+3][top+2]=2;
                a[com][1][tot+3][top+1]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
                a[com][1][tot+8][top]=28;
                a[com][1][tot+8][top-1]=2;
                a[com][1][tot+8][top+1]=2;
                a[com][1][tot+9][top]=2;
            }else{
                a[com][1][tot+4][top]=28;
                a[com][1][tot+5][top]=28;
                a[com][1][tot+6][top]=2;
                a[com][1][tot+3][top-3]=2;
                a[com][1][tot+3][top-2]=2;
                a[com][1][tot+3][top-1]=2;
                a[com][1][tot+3][top+3]=2;
                a[com][1][tot+3][top+2]=2;
                a[com][1][tot+3][top+1]=2;
                a[com][1][tot+4][top-1]=2;
                a[com][1][tot+4][top+1]=2;
                a[com][1][tot+5][top-2]=2;
                a[com][1][tot+5][top-1]=2;
                a[com][1][tot+5][top+2]=2;
                a[com][1][tot+5][top+1]=2;
                a[com][1][tot+6][top-1]=2;
                a[com][1][tot+6][top+1]=2;
                a[com][1][tot+7][top]=2;
            }
            }
        }
        if(i%128==0 && i!=1024) u=rdm(1,100);
    } 
    //
    for(i=1;i<=2048;i++){
        for(j=1;j<=16;j++){
            if(a[com][1][j][i]==3){
                int uuu=rdm(1,1000);
                if(uuu<=1){
                    a[com][1][j][i]=7;
                    a[com][2][j][i]=7;
                }
            }
        }
        for(j=4;j<=32;j++){
            if(a[com][1][j][i]==3){
                int uuu=rdm(1,1000);
                if(uuu<=5){
                    a[com][1][j][i]=8;
                    a[com][2][j][i]=8;
                }
            }
        }
        for(j=1;j<=64;j++){
            if(a[com][1][j][i]==3){
                int uuu=rdm(1,1000);
                if(uuu<=8){
                    a[com][1][j][i]=21;
                    a[com][2][j][i]=21;
                }
            }
        }
        for(j=1;j<=64;j++){
            if(a[com][2][j+4][i]==30 && j>=4){
                int uuu=rdm(1,10000);
                if(uuu>=9999){
                    a[com][2][j-1][i-2]=32;
                    a[com][2][j+0][i-2]=32;
                    a[com][2][j+1][i-2]=32;
                    a[com][2][j-2][i-1]=32;
                    a[com][2][j-1][i-1]=32;
                    a[com][2][j+0][i-1]=32;
                    a[com][2][j+1][i-1]=32;
                    a[com][2][j+2][i-1]=32;
                    a[com][2][j-2][i+0]=32;
                    a[com][2][j-1][i+0]=32;
                    a[com][2][j+0][i+0]=32;
                    a[com][2][j+1][i+0]=32;
                    a[com][2][j+2][i+0]=32;
                    a[com][2][j-2][i+1]=32;
                    a[com][2][j-1][i+1]=32;
                    a[com][2][j+0][i+1]=32;
                    a[com][2][j+1][i+1]=32;
                    a[com][2][j+2][i+1]=32;
                    a[com][2][j-1][i+2]=32;
                    a[com][2][j+0][i+2]=32;
                    a[com][2][j+1][i+2]=32;
                }
                if(uuu>=9900 && uuu<9999){
                    a[com][2][j+150-1][i-2]=33;
                    a[com][2][j+150+0][i-2]=33;
                    a[com][2][j+150+1][i-2]=33;
                    a[com][2][j+150-2][i-1]=33;
                    a[com][2][j+150-1][i-1]=33;
                    a[com][2][j+150+0][i-1]=33;
                    a[com][2][j+150+1][i-1]=33;
                    a[com][2][j+150+2][i-1]=33;
                    a[com][2][j+150-2][i+0]=33;
                    a[com][2][j+150-1][i+0]=33;
                    a[com][2][j+150+0][i+0]=33;
                    a[com][2][j+150+1][i+0]=33;
                    a[com][2][j+150+2][i+0]=33;
                    a[com][2][j+150-2][i+1]=33;
                    a[com][2][j+150-1][i+1]=33;
                    a[com][2][j+150+0][i+1]=33;
                    a[com][2][j+150+1][i+1]=33;
                    a[com][2][j+150+2][i+1]=33;
                    a[com][2][j+150-1][i+2]=33;
                    a[com][2][j+150+0][i+2]=33;
                    a[com][2][j+150+1][i+2]=33;
                }
            }
        }
        for(j=1;j<=256;j++){
            if(a[com][1][j][i]==2){
                int uuu=rdm(1,1000);
                if(uuu<=5){
                    int uuuu=rdm(1,1000);
                    if(uuuu>200) a[com][1][j][i]=9;
                    else a[com][1][j][i]=10;
                }
            }
        }
    } 
}
int died(){
    system("cls");
    color(79);
    system("cls");
    cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl;
    Line("��ʧ���ˣ�");
    cout<<endl<<endl;
    Line("G - ����     P - �˳�");
    while(true){
        if(kd('G')){
            system("cls");
            color(7);
            system("cls");
            return 1;
        }
        if(kd('P')){
            system("cls");
            color(7);
            system("cls");
            return 2;
        }   
    }   
}
void survival(int com){
    cls();
    int ztl=2,highlowdown=0,dek=0;
    while(!(kd('P') || dek==2)){
        cls();
        tims[com]+=1;
        if(tims[com]>=10000){
            days[com]++;
            tims[com]=0;
        }
        if(tims[com]<=5500) chuancan=240;
        else if(tims[com]<=6000) chuancan=224;
        else if(tims[com]<=9500) chuancan=0;
        else chuancan=224;
        if(tims[com]%100==0){
            jb+=(tims[com]+days[com]*10000)/1000;
            emc+=1; 
        }
        for(i=x[com]+10;i>=x[com]-10;i--){
            for(j=y[com]-19;j<=y[com]+19;j++){
                if(i==-1 || j<0 || j>2048){
                    color(15);
                    printf("��");
                }
                /*else if(a[com][jie[com]][i-1][j]!=0 && a[com][jie[com]][i+1][j]!=0 && a[com][jie[com]][i][j+1]!=0 && a[com][jie[com]][i][j-1]!=0){
                    color(7);
                    cout<<"  ";
                }*/else if(i!=x[com] || j!=y[com]){
                    print(a[com][jie[com]][i][j]);
                }else{
                    ppf(sehao);
                }
            }
            cout<<endl;
        }
        if(x[com]<=1){
            x[com]=1;
        }
        if(x[com]>256){
            x[com]=256;
        }
        if(y[com]<0){
            y[com]=0;
        }
        if(y[com]>2048){
            y[com]=2048;
        }
        color(15);
        if(ztl==1){
            printf(">>״̬�� ����: x:%d y:%d ",x[com],y[com]);
            cout<<"��λ����:";
            print(a[com][jie[com]][x[com]][y[com]]);
            color(15);
            cout<<" ��ǰ:";
            if(kn){
                color(12);
                cout<<"�ƻ�"; 
            }else{
                color(10);
                cout<<"����";
            } 
            color(15);
            cout<<"ģʽ(J�л�) P-���沢�˳� ";
        }else if(ztl==2){
            printt(com);
        }
        cout<<endl;
        color(7);
        Line("                               "+wri(hand[com][xuanze].ui)+"                               ");
        color(7);
        cout<<"\t\t\t       ";
        for(i=1;i<=9;i++){
            color(7);
            if(hand[com][i].num!=0){
                print(hand[com][i].ui);
            }else{
                cout<<"��";
            }
        }
        color(7);
        cout<<"                             ";
        cout<<endl<<"\t\t\t       ";
        for(i=1;i<=9;i++){
            if(i==xuanze) color(11);
            else color(7);
            if(hand[com][i].num!=0){
                if(hand[com][i].num<=64) printf("%02d",hand[com][i].num);
                else if(hand[com][i].num<100) cout<<hand[com][i].num%100/10<<"+";
                else if(hand[com][i].num<1000) cout<<hand[com][i].num%1000/100<<"*";
                else cout<<hand[com][i].num%10000/1000<<"^";
            }else{
                cout<<"--";
            }
        }
        cout<<"                             ";
        //Sleep(100);
        if(cmmd=='/'){
            cls();
            color(12);
            Line("����");
            bool flag=0;
            while(comd!="esc"){ 
                color(7);
                cout<<"/";
                cin>>comd;
                if(comd=="tp"){
                    cout<<"/tp @s ";
                    cin>>i>>j;
                    flag=1;
                    x[com]=i;
                    y[com]=j;
                    comd="esc";
                }
                if(!flag){
                    color(12);
                    cout<<">>�﷨����"<<endl;
                    color(7);
                }
            }
            comd="?";
        }
        //��Ѫ���������� ʼ 
        if(a[com][jie[com]][x[com]][y[com]]!=0 && tims[com]%10==0){
            smz[com]-=8;
        }
        if(kd('Z') && tims[com]%2==0){
            if(hand[com][xuanze].ui==9){
                jed[com]+=20;
                del(com,9,1);
            }
            if(hand[com][xuanze].ui==10){
                smz[com]+=10;
                jed[com]+=40;
                del(com,10,1);
            }
        }
        if(tims[com]%50==0 && jed[com]>=30){
            smz[com]++;
        }
        if(tims[com]%100==0){
            jed[com]-=2;
        }
        if(smz[com]>=100) smz[com]=100;
        if(jed[com]>=100) jed[com]=100;
        if(a[com][jie[com]][x[com]-1][y[com]]==0) highlowdown++;
        else{
            if(highlowdown>=5) smz[com]-=(highlowdown-4)*3;
            highlowdown=0;
        }
        if(a[com][jie[com]][x[com]-1][y[com]]==14 || a[com][jie[com]][x[com]+1][y[com]]==14 || a[com][jie[com]][x[com]][y[com]-1]==14 || a[com][jie[com]][x[com]][y[com]+1]==14){
            if(tims[com]%10==0) smz[com]-=5;
        }
        if(smz[com]<=0){
            jed[com]=smz[com]=100;
            x[com]=cx[com];
            y[com]=cy[com];
            dek=died();
        }
        if(jed[com]<=0){
            jed[com]=0;
            if(tims[com]%25==0) smz[com]-=2;
        }
        if(kd('Z')){
            if(hand[com][xuanze].ui==31){
                a[com][2][x[com]][y[com]]=0;
                a[com][2][x[com]-1][y[com]]=3;
                a[com][2][x[com]-1][y[com]-1]=3;
                a[com][2][x[com]-1][y[com]+1]=3;
                jie[com]=2;
            }
            if(hand[com][xuanze].ui==34){
                a[com][1][x[com]][y[com]]=0;
                a[com][1][x[com]-1][y[com]]=30;
                a[com][1][x[com]-1][y[com]-1]=30;
                a[com][1][x[com]-1][y[com]+1]=30;
                jie[com]=1;
            }
        }
        //��Ѫ���������� �� 
        if(kd('L')){
            if(ztl==1) ztl=2;
            else ztl=1;
            Sleep(200);
        }
        if(kd('E')){
            while(kd('E')){ 
            }
            packback(com);
            Sleep(100);
        }
        if(fool_days()){
            if(kd('S')&& a[com][jie[com]][x[com]-1][y[com]]!=0){
                if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]==0)){
                    x[com]+=4;
                }
                else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]!=0)){
                    x[com]+=3;
                }
                else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]!=0)){
                    x[com]+=2;
                }
            }
            //if(cmmd=='S' || cmmd=='s') x[com]--;
            if(a[com][jie[com]][x[com]-1][y[com]]==0){
                Sleep(20);
                x[com]--;
            }
            if(kd('D')){
                if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]==0){
                    x[com]--;
                    y[com]--;
                }
                else if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]!=0){
                    y[com]--;
                }
                else if(a[com][jie[com]][x[com]][y[com]-1]!=0 && a[com][jie[com]][x[com]+1][y[com]-1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                    x[com]++;
                    y[com]--;
                }
            } //y[com]--;
            if(kd('A')){
                if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]==0){
                    x[com]--;
                    y[com]++;
                }
                else if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]!=0){
                    y[com]++;
                }
                else if(a[com][jie[com]][x[com]][y[com]+1]!=0 && a[com][jie[com]][x[com]+1][y[com]+1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                    x[com]++;
                    y[com]++;
                }
            } //y[com]++;   
        }else{
                if(kd('W')&& a[com][jie[com]][x[com]-1][y[com]]!=0){
                if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]==0)){
                    x[com]+=4;
                }
                else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]!=0)){
                    x[com]+=3;
                }
                else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]!=0)){
                    x[com]+=2;
                }
            }
            //if(cmmd=='S' || cmmd=='s') x[com]--;
            if(a[com][jie[com]][x[com]-1][y[com]]==0){
                Sleep(20);
                x[com]--;
            }
            if(kd('A')){
                if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]==0){
                    x[com]--;
                    y[com]--;
                }
                else if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]!=0){
                    y[com]--;
                }
                else if(a[com][jie[com]][x[com]][y[com]-1]!=0 && a[com][jie[com]][x[com]+1][y[com]-1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                    x[com]++;
                    y[com]--;
                }
            } //y[com]--;
            if(kd('D')){
                if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]==0){
                    x[com]--;
                    y[com]++;
                }
                else if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]!=0){
                    y[com]++;
                }
                else if(a[com][jie[com]][x[com]][y[com]+1]!=0 && a[com][jie[com]][x[com]+1][y[com]+1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                    x[com]++;
                    y[com]++;
                }
            } //y[com]++;
        }
        if(kd('J')){
            kn=!kn;
            while(kd('J')){
            }
        } 
        if(kd('1')) xuanze=1;
        if(kd('2')) xuanze=2;
        if(kd('3')) xuanze=3;
        if(kd('4')) xuanze=4;
        if(kd('5')) xuanze=5;
        if(kd('6')) xuanze=6;
        if(kd('7')) xuanze=7;
        if(kd('8')) xuanze=8;
        if(kd('9')) xuanze=9;
        if(kd('Q') && a[com][jie[com]][x[com]+1][y[com]]==0 && /*a[com][jie[com]][x[com]-1][y[com]]!=0 &&*/ hand[com][xuanze].num!=0){
            x[com]++;
            pt(com,jie[com],x[com]-1,y[com],true);
        }
        if(fool_days()){
        if(kn){
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,false);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],false);
            } 
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,false);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,false);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,false);
            }
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,false);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],false);
            }
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,false);
            }
        }
        if(!kn){
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,true);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],true);
            } 
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,true);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,true);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,true);
            }
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,true);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],true);
            }
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,true);
            }
        }   
        }else{
            if(kn){
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,false);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],false);
            } 
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,false);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,false);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,false);
            }
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,false);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],false);
            }
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,false);
            }
        }
        if(!kn){
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,true);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],true);
            } 
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,true);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,true);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,true);
            }
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,true);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],true);
            }
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,true);
            }
        }
        }
        color(7);
    }
    while(kd('P')){
    }
    cmmd='?';
    while(cmmd!='P' && cmmd!='p'){
        cmmd=getch();
    }
    cmmd='?';
}
void create(int com){
    cls();
    while(!kd('P')){
        cls();
        tims[com]+=1;
        if(tims[com]>=10000){
            days[com]++;
            tims[com]=0;
        }
        if(tims[com]<=5500) chuancan=240;
        else if(tims[com]<=6000) chuancan=224;
        else if(tims[com]<=9500) chuancan=0;
        else chuancan=224;
        if(tims[com]%100==0){
            jb+=(tims[com]+days[com]*10000)/1000;
            emc+=1;
        }
        for(i=x[com]+10;i>=x[com]-10;i--){
            for(j=y[com]-19;j<=y[com]+19;j++){
                if(i==-1 || j<0 || j>2048){
                    color(15);
                    printf("��");
                }
                /*else if(a[com][jie[com]][i-1][j]!=0 && a[com][jie[com]][i+1][j]!=0 && a[com][jie[com]][i][j+1]!=0 && a[com][jie[com]][i][j-1]!=0){
                    color(7);
                    cout<<"  ";
                }*/else if(i!=x[com] || j!=y[com]){
                    print(a[com][jie[com]][i][j]);
                }else{
                    ppf(sehao);
                }
            }
            cout<<endl;
        }
        if(x[com]<=1){
            x[com]=1;
        }
        if(x[com]>256){
            x[com]=256;
        }
        if(y[com]<0){
            y[com]=0;
        }
        if(y[com]>2048){
            y[com]=2048;
        }
        color(15);
        printf(">>״̬�� ����: x:%d y:%d ",x[com],y[com]);
        cout<<"��λ����:";
        print(a[com][jie[com]][x[com]][y[com]]);
        color(15);
        cout<<" ��ǰ:";
        if(kn){
            color(12);
            cout<<"�ƻ�"; 
        }else{
            color(10);
            cout<<"����";
        } 
        color(15);
        cout<<"ģʽ(J�л�) P-���沢�˳� ";
        cout<<endl;
        color(7);
        Line("                               "+wri(hand[com][xuanze].ui)+"                               ");
        color(7);
        cout<<"\t\t\t       ";
        for(i=1;i<=9;i++){
            color(7);
            if(hand[com][i].num!=0){
                print(hand[com][i].ui);
            }else{
                cout<<"��";
            }
        }
        color(7);
        cout<<"                             ";
        cout<<endl<<"\t\t\t       ";
        for(i=1;i<=9;i++){
            if(i==xuanze) color(11);
            else color(7);
            if(hand[com][i].num!=0){
                if(hand[com][i].num<=64) printf("%02d",hand[com][i].num);
                else if(hand[com][i].num<100) cout<<hand[com][i].num%100/10<<"+";
                else if(hand[com][i].num<1000) cout<<hand[com][i].num%1000/100<<"*";
                else cout<<hand[com][i].num%10000/1000<<"^";
            }else{
                cout<<"--";
            }
        }
        cout<<"                             ";
        //Sleep(100);
        if(cmmd=='/'){
            cls();
            color(12);
            Line("����");
            bool flag=0;
            while(comd!="esc"){ 
                color(7);
                cout<<"/";
                cin>>comd;
                if(comd=="tp"){
                    cout<<"/tp @s ";
                    cin>>i>>j;
                    flag=1;
                    x[com]=i;
                    y[com]=j;
                    comd="esc";
                }
                if(!flag){
                    color(12);
                    cout<<">>�﷨����"<<endl;
                    color(7);
                }
            }
            comd="?";
        }
        if(kd('V')){
            pus(com,31,1);
        }
        if(kd('Z')){
            if(hand[com][xuanze].ui==31){
                a[com][2][x[com]][y[com]]=0;
                a[com][2][x[com]-1][y[com]]=3;
                a[com][2][x[com]-1][y[com]-1]=3;
                a[com][2][x[com]-1][y[com]+1]=3;
                jie[com]=2;
            }
            if(hand[com][xuanze].ui==34){
                a[com][1][x[com]][y[com]]=0;
                a[com][1][x[com]-1][y[com]]=30;
                a[com][1][x[com]-1][y[com]-1]=30;
                a[com][1][x[com]-1][y[com]+1]=30;
                jie[com]=1;
            }
        }
        if(kd('E')){
            while(kd('E')){ 
            }
            packback(com);
            Sleep(100);
        }
        if(kd('W')&& a[com][jie[com]][x[com]-1][y[com]]!=0){
            if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]==0)){
                x[com]+=4;
            }
            else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]==0) && (a[com][jie[com]][x[com]+3][y[com]]!=0)){
                x[com]+=3;
            }
            else if((a[com][jie[com]][x[com]+1][y[com]]==0) && (a[com][jie[com]][x[com]+2][y[com]]!=0)){
                x[com]+=2;
            }
        }
        //if(cmmd=='S' || cmmd=='s') x[com]--;
        if(a[com][jie[com]][x[com]-1][y[com]]==0){
            Sleep(20);
            x[com]--;
        }
        if(kd('A')){
            if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]==0){
                x[com]--;
                y[com]--;
            }
            else if(a[com][jie[com]][x[com]][y[com]-1]==0 && a[com][jie[com]][x[com]-1][y[com]-1]!=0){
                y[com]--;
            }
            else if(a[com][jie[com]][x[com]][y[com]-1]!=0 && a[com][jie[com]][x[com]+1][y[com]-1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                x[com]++;
                y[com]--;
            }
        } //y[com]--;
        if(kd('D')){
            if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]==0){
                x[com]--;
                y[com]++;
            }
            else if(a[com][jie[com]][x[com]][y[com]+1]==0 && a[com][jie[com]][x[com]-1][y[com]+1]!=0){
                y[com]++;
            }
            else if(a[com][jie[com]][x[com]][y[com]+1]!=0 && a[com][jie[com]][x[com]+1][y[com]+1]==0 && a[com][jie[com]][x[com]+1][y[com]]==0){
                x[com]++;
                y[com]++;
            }
        } //y[com]++;
        if(kd('J')){
            kn=!kn;
            while(kd('J')){
            }
        } 
        if(kd('1')) xuanze=1;
        if(kd('2')) xuanze=2;
        if(kd('3')) xuanze=3;
        if(kd('4')) xuanze=4;
        if(kd('5')) xuanze=5;
        if(kd('6')) xuanze=6;
        if(kd('7')) xuanze=7;
        if(kd('8')) xuanze=8;
        if(kd('9')) xuanze=9;
        if(kd('Q') && a[com][jie[com]][x[com]+1][y[com]]==0 && /*a[com][jie[com]][x[com]-1][y[com]]!=0 &&*/ hand[com][xuanze].num!=0){
            x[com]++;
            pt(com,jie[com],x[com]-1,y[com],true);
        }
        if(kn){
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,false);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],false);
            } 
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,false);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,false);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,false);
            }
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,false);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],false);
            }
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,false);
            }
        }
        if(!kn){
            if(kd('Y')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]-1]]++;
                //a[com][jie[com]][x[com]+1][y[com]-1]=0;
                pt(com,jie[com],x[com]+1,y[com]-1,true);
            }
            if(kd('U')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]]]++;
                //a[com][jie[com]][x[com]+1][y[com]]=0;
                pt(com,jie[com],x[com]+1,y[com],true);
            } 
            if(kd('I')){
                //hand[com][a[com][jie[com]][x[com]+1][y[com]+1]]++;
                //a[com][jie[com]][x[com]+1][y[com]+1]=0;
                pt(com,jie[com],x[com]+1,y[com]+1,true);
            }
            if(kd('H')){
                //hand[com][a[com][jie[com]][x[com]][y[com]-1]]++;
                //a[com][jie[com]][x[com]][y[com]-1]=0;
                pt(com,jie[com],x[com],y[com]-1,true);
            }
            if(kd('K')){
                //hand[com][a[com][jie[com]][x[com]][y[com]+1]]++;
                //a[com][jie[com]][x[com]][y[com]+1]=0;
                pt(com,jie[com],x[com],y[com]+1,true);
            }
            if(kd('B')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]-1]]++;
                //a[com][jie[com]][x[com]-1][y[com]-1]=0;
                pt(com,jie[com],x[com]-1,y[com]-1,true);
            }
            if(kd('N')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]]]++;
                //a[com][jie[com]][x[com]-1][y[com]]=0;
                pt(com,jie[com],x[com]-1,y[com],true);
            }
            if(kd('M')){
                //hand[com][a[com][jie[com]][x[com]-1][y[com]+1]]++;
                //a[com][jie[com]][x[com]-1][y[com]+1]=0;
                pt(com,jie[com],x[com]-1,y[com]+1,true);
            }
        }
        color(7);
    }
    while(kd('P')){
    }
    cmmd='?';
    while(cmmd!='P' && cmmd!='p'){
        cmmd=getch();
    }
    cmmd='?';
}
int cun(int com)
{
    while(kd(char(13))){
    }
    xuanze=1;
    chuandang=com;
    color(255);
    //for(i=1;i<=1000;i++) cout<<" ";
    if(mode[com]==1){
        survival(com);
    }else if(mode[com]==2){
        create(com);
    }
    return 0;
}
void fm(){
    while(cmmd!='G' && cmmd!='g'){
        system("cls");
        color(240);
        system("cls");
        cout<<endl;
        Line("XACRAFT 3.3");
        cout<<endl<<endl;
        color(249);
        Line(" �������Ŷ�\n"); 
        color(240);
        Line("���ĳ���/������ ɳ巰�");
        Line("");
        cout<<endl;
        color(249);
        Line(" �ر���л����\n"); 
        color(240);
        Line(" ע���������������Ⱥ�\n");
        cout<<endl;
        Line("����ï��  �� �� ��  �� Ӣ ��  �� �� ��  �� ƽ ��");
        Line("ŷ�����  ��    ��  �� �� ��  �� �� ��  ��    ��");
        Line("�� �� ��  �� �� ��  �� С ��  �� �� ��  �� �� ҫ");
        Line("�� �� ��  �� �� ��  �� Т ��  �� �� ��  �� �� ��");
        Line("֣ �� ��  �� �� ��  �� �h ��  �� ̩ ��  Ѧ �� ־");
        color(252);
        cout<<endl;
        Line("ע����������л�����ϵ��˿��������Ƴ����ﵽ���ܼ������ϵ��˿���������롣");
        color(240);
        Line("[1/2]");
        Line("G-�л���һҳ");
        cmmd=getch();
    }
    while(cmmd!='S' && cmmd!='s'){
        system("cls");
        color(240);
        system("cls");
        cout<<endl;
        Line("XACRAFT 3.3");
        cout<<endl<<endl;
        color(249);
        Line(" ���汾��������\n"); 
        color(240);
        Line("����XACRAFT�ĵ�7���汾");
        Line("���汾�����������£�");
        cout<<endl;
        Line("�浵�Զ�����");
        Line("");
        Line("�½����");
        cout<<endl;
        color(252);
        Line(" XACRAFT�������Ŷ�Ԥף��������죡\n");
        color(249);
        Line(" ��Ȩ����\n"); 
        color(240);
        Line("����Ϸ���˰��Ƽ�����");
        Line("��Ȩ���� δ����Ȩ�Ͻ�ת�� ��������Ȩ��");
        Line("Copyright XAscience All Rights Reserved"); 
        cout<<endl; 
        color(240);
        Line("[2/2]");
        Line("S-��ʼ��Ϸ");
        cmmd=getch();
    }
    while(cmmd!='O' && cmmd!='o'){
        system("cls");
        color(240);
        system("cls");
        if(xanam.empty()) rightLine("δ��¼XA�˺�  L-��¼");
        else rightLine(xanam+",��ӭ����");
        color(240);
        cout<<"                                                                               "<<endl;
        cout<<"                �~  �~   �~   �~�~�~ �~�~�~   �~   �~�~�~ �~�~�~               "<<endl;
        cout<<"                �~  �~ �~  �~ �~     �~  �~ �~  �~ �~       �~                 "<<endl;
        cout<<"                  �~   �~�~�~ �~     �~�~�~ �~�~�~ �~�~�~   �~                 "<<endl;
        cout<<"                �~  �~ �~  �~ �~     �~�~   �~  �~ �~       �~                 "<<endl;
        cout<<"                �~  �~ �~  �~ �~�~�~ �~  �~ �~  �~ �~       �~                 "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                           ";
        color(143);
        cout<<"       F-������Ϸ       ";
        color(240);
        cout<<"                            "<<endl; 
        cout<<"                                                                               "<<endl;
        cout<<"                           ";
        color(143);
        cout<<"  G-XACRAFT  Community  ";
        color(240);
        cout<<"                            "<<endl; 
        cout<<"                                                                               "<<endl;
        cout<<"                           ";
        color(143);
        cout<<"       B-�ٷ���̬       ";
        color(240);
        cout<<"                            "<<endl; 
        cout<<"                                                                               "<<endl;
        cout<<"                           ";
        color(143);
        cout<<"       H-��������       ";
        color(240);
        cout<<"                            "<<endl; 
        cout<<"                                                                               "<<endl;
        cout<<"                           ";
        color(143);
        cout<<"  J-�̳�  ";
        color(240);
        cout<<"    "; 
        color(143);
        cout<<"  O-�˳�  ";
        color(240);
        cout<<"                            "<<endl; 
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<"                                                                               "<<endl;
        cout<<" XACRAFT 3.3                             Copyright XAscience Do not distribute!";
        cmmd=getch();
        if(cmmd=='F' || cmmd=='f'){
            while(cmmd!='P' && cmmd!='p'){
                system("cls");
                color(252);
                system("cls");
                Line("�ҵĴ浵");
                color(240);
                Line("______________________________________________________________________________");
                j=0;
                for(i=1;i<=20;i++){
                    if(jiandang[i]){
                        cout<<" "<<i<<" - XACRAFT�浵"<<i<<endl;
                        j++;
                    }
                }
                for(i=1;i<=20-j;i++) cout<<endl;
                Line("______________________________________________________________________________");
                Line("F-�½��浵  G-��ȡ�浵  H-ɾ���浵  P-�˳�");
                cmmd=getch();
                if(cmmd=='F' || cmmd=='f'){
                    for(i=1;i<=20;i++){
                        if(!jiandang[i]){
                            nw(i);
                            jiandang[i]=1;
                            break;
                        }
                    }
                }
                if(cmmd=='G' || cmmd=='g'){
                    system("cls");
                    color(252);
                    system("cls");
                    Line("�ҵĴ浵");
                    color(240);
                    Line("��ȡ�浵"); 
                    cout<<endl<<endl;
                    line("�浵���(���븺���˳�): ");
                    color(7);
                    cin>>comd;
                    kkk=change_num(comd);
                    comd="?";
                    if(kkk>=0 && jiandang[kkk]){
                        cun(kkk);
                        system("cls");/*
                        color(12);
                        Line("XACRAFT�浵�쳣�˳�");
                        color(7);
                        cout<<endl<<"    ������ת���˽��棬��������Ϊ����ʹ��XACRAFT�浵�Ĺ�����δ�����ַ�����(���ַ�������ִ�е������)���������������ݣ�Ȼ��Enter�������˳�XACRAFT�浵";
                        cin>>comd;
                        system("cls");*/
                    }
                }
                if(cmmd=='H' || cmmd=='h'){
                    system("cls");
                    color(252);
                    system("cls");
                    Line("�ҵĴ浵");
                    color(240);
                    Line("ɾ���浵"); 
                    cout<<endl<<endl;
                    line("�浵���(���븺���˳�): ");
                    color(7);
                    cin>>comd;
                    kkk=change_num(comd);
                    comd="?";
                    if(kkk>=0) jiandang[kkk]=0;
                }
                /*
                if(jiandang){
                    color(7);
                    cun(1);
                    cmmd='?';
                }else{
                    system("cls");
                    color(252);
                    system("cls");
                    Line("�ҵĴ浵");
                    color(240);
                    Line("�µ�����"); 
                    cout<<endl<<endl;
                    line("��������: ");
                    color(7);
                    nw(1);
                    cun(1);
                    cmmd='?';
                    jiandang=1;
                }
                */
            }   
            cmmd='?';
        }
        if(cmmd=='G' || cmmd=='g'){
            system("cls");
            color(252);
            system("cls");
            Line("XACRAFT Community");
            cout<<endl;
            color(240);
            Line("�뱣֤�������˻������������޷�����XACRAFT Community��"); 
            system("start https://www.luogu.com.cn/team/35439");
            cout<<endl<<endl<<endl<<endl;
            Line("[��������˳�]");
            cmmd=getch();
            cmmd='?';
        }
        if(cmmd=='H' || cmmd=='h') mycenter();
        if(cmmd=='L' || cmmd=='l') XAlogin();
        if(cmmd=='J' || cmmd=='j'){
            system("cls");
            color(240);
            system("cls");
            Line("���ֽ̳�");
            cout<<endl;
            color(240);
            Line(" ע�����¼�λ������Сд�Կ�\n");
            Line(" W-��  Ծ   A-��  ��   D-��  ��  Q-�ڽ��·��÷���\n");
            Line(" J-����ģʽ/�ƻ�ģʽ\n");
            Line(" YUIHKBNM����Ϊ:����/�ƻ�{���Ͻ�,�Ϸ�,���Ͻ�,���,�ұ�,���½�,�·�,���½�}�ķ���\n");
            Line(" ��Ϸ��������·�Ϊ��Ʒ��\n");
            Line(" ����̳��밴K��\n");
            Line(" �������������밴H��\n");
            cout<<endl<<endl<<endl;
            Line("[���������˳�]");
            cmmd=getch();
            if(cmmd=='K' || cmmd=='k') system("start https://docs.qq.com/doc/DWHBzc1BxdndySm9l");
            if(cmmd=='H' || cmmd=='h') xsyd();
            cmmd='?';
        }
        if(cmmd=='B' || cmmd=='b'){
            system("cls");
            color(252);
            system("cls");
            Line("�ٷ���̬");
            cout<<endl;
            color(240);
            Line("�뱣֤�������˻������������޷��鿴�ٷ���̬��"); 
            system("start https://www.luogu.com.cn/blog/XAscience/");
            cout<<endl<<endl<<endl<<endl;
            Line("[��������˳�]");
            cmmd=getch();
            cmmd='?';
        }
        if(cmmd=='#'){
            system("cls");
            color(12);
            system("cls");
            Line("����ģʽ");
            cout<<endl;
            color(7);
            Line("ע����ģʽ����XACRAFT�ڲ���Աʹ�ã����������XACRAFT������Ա����ʹ��XACRAFT����ģʽ������������������⣬�˰��Ƽ��ͼ��繤�������е��κ����Ρ�");
            cout<<endl<<endl;
            cout<<"�������:";
            for(i=1;i<=35;i++){
                print(i);
                color(7);
            }
            color(7);
            cout<<endl<<"����UIֵ:";
            for(i=1;i<=35;i++){
                if(i%2==1) color(9);
                printf("%02d",i);
                color(7);
            }
            cout<<endl<<endl<<endl;
            Line("[��������˳�]");
            cmmd=getch();
            cmmd='?';
        }
    }
    Sleep(1000);
    return ;
}
void exit_saving(){
    sav();
}
void XACRAFT_MAIN(){
    console();
    HideCursor1();
    Logical_Lock();
    lists();
    checkcun();
    rea();
    fm();
}
int main(){
	init();
    atexit(exit_saving);
    XACRAFT_MAIN();
    return 0;
}
