 #include<algorithm>
#include<bits/stdc++.h>
#include<iostream>
#include<cstdio>
#include<windows.h>
#include<ctime>
#include <fstream>
#include <time.h>
#define KEY_DOWN(VK_NONAME) ((GetAsyncKeyState(VK_NONAME) & 0x8000)
#define clear_cin() fflush(stdin)
#include<conio.h>
using namespace std;
string s,t;

long long sr=0;

bool kj=1;
int windowsXPkj=5;
int windows11kj=5;
int choose;
int guanji;
void tiaoshi(){
	cout<<"����";
	Sleep(1000);
	system("cls"); 
	cout<<"Ϊ������ʹ�����飬��������һЩУ����"; 
	Sleep(1000);
	system("cls"); 
	cout<<"�����㽫�ῴ�������壬��ctrl+�������������ξ��С����������ⰴ���˳���5s�������";
	Sleep(1000); 
	system("cls");
	cout<<"�����㽫�ῴ�������壬��ctrl+�������������ξ��С����������ⰴ���˳���4s�������";
	Sleep(1000); 
	system("cls");
	cout<<"�����㽫�ῴ�������壬��ctrl+�������������ξ��С����������ⰴ���˳���3s�������";
	Sleep(1000); 
	system("cls");
	cout<<"�����㽫�ῴ�������壬��ctrl+�������������ξ��С����������ⰴ���˳���2s�������";
	Sleep(1000); 
	system("cls");
	cout<<"�����㽫�ῴ�������壬��ctrl+�������������ξ��С����������ⰴ���˳���1s�������";
	Sleep(1000); 
	system("cls");
	system("cls");
	cout<<"\n\n\n\n\n\n\n";
	cout<<"                                  �� ��\n";
	cout<<"                                  �� ��\n\n";
	cout<<"                               . .  .  .."; 
	int ch1=0;
    int ch2=0;
    int brhh=0;
	while (1){
        	if(brhh==1){
        		break; 
			}
          if (ch1=getch())
          { 
             ch2=getch();//��һ�ε���getch()������ֵ224
             switch (ch2)//�ڶ��ε���getch()
             { 
            default: brhh=1;break;
            break;
            }
          }  
        }
    system("cls");
	ofstream ofs;
	ofs.open("test.txt", ios::out);
 
	ofs << 1 << endl;
 
	ofs.close();
	Sleep(2000); 
}
void brc()
{
	system("cls");
	long long jy=1,wd=3;
	long long sy=3,wj=3;
	srand((int)time(0));
	long long n=rand()%15+1;
	cout<<"                                ����"<<n<<"��"<<endl;
	cout<<"                               ���ڷ�������"<<endl;
	Sleep(1500);
	long long m[20];
	for(long long i=1;i<=15;i++)
		m[i]=1;
	long long s[20]={0};
	long long yy[20]={0};
	long long l=0,w=0,j=0,p=0;
	for(long long i=1;i<=15;i++)
	{
		do
		{
			long long a=rand()%4+1;
			if(a==1&&l<1)
			{
				l++;
				s[i]=1;
				sr=i;
			}
			else if(a==2&&w<2)
			{
				w++;
				s[i]=2;
			}
			else if(a==4&&p<3)
			{
				p++;
				s[i]=4;
			}
			else if(a==3&&j<9
			)
			{
				j++;
				s[i]=3;
			}
		}
		while(s[i]==0);
	}
	if(s[n]==1)
		cout<<"                               ����>>ɱ��<<"<<endl;
	else if(s[n]==2)
		cout<<"                               ����>>Ԥ�Լ�<<"<<endl;
	else if(s[n]==3)
		cout<<"                               ����>>ƽ��<<"<<endl;
	else
		cout<<"                               ����>>��ʦ<<"<<endl;
	cout<<"                             ��Ϸ����5���ʼ"<<endl; 
	Sleep(5000);
	long long c=15;
	long long f=0,flag=0;
	long long day=1;
	long long lr;
	long long tp[20]={0};
	do
	{
		lr=0;
		system("cls");
		cout<<"                                 ��"<<day<<"����ʼ"<<endl;
		cout<<"����"<<n<<"��"<<endl;
		long long x;
		for(long long i=1;i<=15;i++) 
		{
			if(i==n&&m[n]==1)
			{
				if(s[n]==1)
				{
					cout<<"                                 ����ɱ��"<<endl;
					for(long long j=1;j<=15;j++)
						if(m[j]==1&&s[j]!=1)
							cout<<j<<" ";
					cout<<endl;
					cout<<"                                 ��ѡ��ɱ��"<<endl; 
					long long a;
					cin>>a;
					m[a]=0;
					cout<<endl;
					cout<<"                                 ɱ��ɱ��"<<a<<"��"; 
					if(s[a]==1)
						cout<<"(ɱ��)"<<endl;
					else if(s[a]==2)
						cout<<"(Ԥ�Լ�)"<<endl;
					else if(s[a]==3)
						cout<<"(ƽ��)"<<endl;
					else
						cout<<"(��ʦ)"<<endl;
					c--;
				}	
				else
				if(s[n]==2)
				{
					cout<<"                                 ����Ԥ�Լ�"<<endl;
					cout<<"                               ";
					for(long long j=1;j<=15;j++)
						if(m[j]==1)
							cout<<j<<" ";
					cout<<endl<<"                              ��ѡ��Ԥ��˭������"<<endl;
					long long a;
					cin>>a;
					if(s[a]==1)
					{
						cout<<"                        "<<a<<"����ɱ�֣���ע��"<<endl;
						Sleep(1000);
					}
					else
						cout<<"                            "<<a<<"���Ǻ���"<<endl; 
				}
			}
			else if(s[i]==1&&m[i]==1)
			{
				long long a;
				do
				{
					a=rand()%15+1;
				}
				while(a==i||m[a]==0||s[a]==1);
				cout<<"                           ɱ��ɱ����"<<a<<"��"; 
				if(s[a]==1)
					cout<<"(ɱ��)"<<endl;
				else if(s[a]==2)
					cout<<"(Ԥ�Լ�)"<<endl;
				else if(s[a]==3)
					cout<<"(ƽ��)"<<endl;
				else
					cout<<"(��ʦ)"<<endl;
				m[a]=0;
				c--;
				break;//
			}
			else if(s[i]==2)
			{
				if(flag==0||m[flag]==0)
				{
					long long a;
					do
					{
						a=rand()%15+1;
					}
					while(a==i||m[a]==0);
					if(s[a]==1)
						yy[a]=1;	
					else if(s[a]==3)
						yy[a]=3;
				}	
			}
			else if(s[i]==4)
			{
				f=0;
				while(f==0)
				{
					long long a;
					a=rand()%3+1;
					if(a==3)break;
					if(a==1)
					{
						if(sy>0)
						{
							sy--;
							f=1; 
							long long b;
							do
							{
								b=rand()%15+1;
								b=rand()%15+1;
							}
							while(b==i||m[b]==0);
							m[b]=0;
							cout<<"                           ��ʦ������"<<b<<"��"; 
							if(s[b]==1)
								cout<<"(ɱ��)"<<endl;
							else if(s[b]==2)
								cout<<"(Ԥ�Լ�)"<<endl;
							else if(s[b]==3)
								cout<<"(ƽ��)"<<endl;
							c--;
							if(s[b]==1&&n!=sr)
							{
								cout<<endl<<"							   "<<sr<<"����ɱ�֣�"; 
								cout<<endl<<"								ɱ����������"<<endl;
								cout<<"                          	��Ϸ����"<<endl;
								return ;
							}
							break;//
						}
					}
					else if(a==2&&day>1)
					{
						if(jy>0)
						{
							jy--;
							f=1; 
							long long b;
							do
							{
								b=rand()%15+1;
							}
							while(b==i||m[b]==1);
							c++;
							cout<<"                           ��ʦ������"<<b<<"��"<<endl;
							m[b]=1;
							if(m[sr]==0&&n!=sr)
							{
								cout<<endl<<"							   "<<sr<<"����ɱ�֣�"; 
								cout<<endl<<"						ɱ����������"<<endl;
								cout<<"                          	��Ϸ����"<<endl;
								return ;
							}
							break;//
						}
					}
					
				}
			}
		}
		if(s[n]==4)
		{
			cout<<"                                 ���Ƿ�ʦ"<<endl;
			cout<<"���״����"<<endl; 
			for(long long j=1;j<=15;j++)
				if(m[j]==1)
					cout<<j<<" ";
			cout<<endl;
			cout<<"                        ��ѡ�� 1.* ɱ *���� 2.* �� * 3.* ɶ������ *"<<endl;
			long long a,f=0;
			while(f==0)
			{
				cin>>a;
				if(a==3) break;
				if(a==1)
				{
					if(wd>0)
					{
						wd--;
						f=1; 
						cout<<"                                ��ѡ����ɱ��"<<endl;
						for(long long i=1;i<=15;i++)
							if(m[i]==1)
								cout<<i<<" ";
						cout<<endl; 
						long long b;
						cin>>b;
						if(s[b]==1)
							cout<<"(ɱ��)"<<endl;
						else if(s[b]==2)
							cout<<"(Ԥ�Լ�)"<<endl;
						else if(s[b]==3)
							cout<<"(ƽ��)"<<endl;
						else
							cout<<"(��ʦ)"<<endl;
						m[b]=0;
						c--; 
						if(m[sr]==0&&n!=sr)
						{
							cout<<endl<<"							   "<<sr<<"����ɱ�֣�"; 
							cout<<endl<<"						ɱ����������"<<endl;
							cout<<"                          	��Ϸ����"<<endl;
							return ;
						}
					}
					else
					{
						cout<<">>��ҩ<<����"<<endl; 
					}
				}
				else if(a==2)
				{
					if(wj>0)
					{
						wj--;
						f=1; 
						cout<<"��ѡ���˸���"<<endl;
						cout<<"����������"<<endl;
						for(long long i=1;i<=15;i++)
							if(m[i]==0)
								cout<<i<<"��,����:"<<s[i]<<" "<<endl;;
						long long b;
						cin>>b;
						m[b]=1;
						c++;
					}
					else
					{
						cout<<">>����ҩˮ<<����"<<endl; 
					}
				}
			}
		}
		Sleep(1000);
		long double p[20]={0};
		cout<<"                                 ��"<<day<<"������"<<endl;
		cout<<endl;
		if(m[n]==0)
		{
			cout<<"                             ���Ѿ�>>��<<��";	
			break;
		}
		
		cout<<"                                    ��"<<endl;
		cout<<"                       ";
		for(long long i=1;i<=15;i++)
			if(m[i]==1)
				cout<<i<<" ";
		cout<<endl;
		cout<<"                                    ��ͶƱ...."<<endl;
		for(long long i=1;i<=15;i++)
		{
			if(i==n&&m[n]==1)
			{
				cout<<endl;
				cout<<"                                 ��ѡ��Ͷ����"<<endl; 
				long long a=99;
				while(a==99) 
				{
					cin>>a;
					if(a==99)
						for(long long i=1;i<=15;i++)
							if(m[i]==1)
								cout<<"                                    "<<i<<"."<<s[i]<<endl;
				}
				if(s[i]==3&&day>4)
					p[a]+=1.5;
				else
					p[a]++;	
				cout<<endl;
				cout<<"                                    "<<i<<"->"<<a<<endl;
				if(s[a]==3)
				{
					tp[a]=i;
				}
			}
			else if(s[i]==1&&m[i]==1)
			{
				long long a;
				do
				{
					a=rand()%15+1;	
				}
				while(m[a]==0||a==i||s[a]==1);
				p[a]++;
				cout<<"                                    "<<i<<"->"<<a<<endl;
				if(s[a]==3)
				{
					tp[a]=i;
				}
			}
			else if(s[i]==2&&m[i]==1)
			{
				if(flag!=0)
				{
					p[f]++;
					cout<<"                                    "<<i<<"->"<<flag<<endl;
				}
				else
				{
					long long a;
					do
					{
						a=rand()%15+1;	
					}
					while(m[a]==0||a==i||yy[a]==3);
					p[a]++;
					if(s[a]==3)	
					{
						tp[a]=i;
					}
					cout<<"                                    "<<i<<"->"<<a<<endl;
				}
			} 
			else if(s[i]==3&&m[i]==1)
			{
				if(tp[i]==0)
				{
					long long a;
					do
					{
						a=rand()%15+1;	
					}
					while(m[a]==0||a==i);
					p[a]++;
					cout<<"                                    "<<i<<"->"<<a<<endl;
				}
				else
				{
					if(m[tp[i]]==1)
					{
						p[tp[i]]++;
						cout<<"                                    "<<i<<"->"<<tp[i]<<endl;
					}
					else
					{
						long long a;
						do
						{
							a=rand()%15+1;	
						}
						while(m[a]==0||a==i);
						p[a]++;
						cout<<"                                    "<<i<<"->"<<a<<endl;
					}
				}
			}
			else if(s[i]==4&&m[i]==1)
			{
				long long a;
				do
				{
					a=rand()%15+1;	
				}
				while(m[a]==0||a==i);
				p[a]++;
				cout<<"                                    "<<i<<"->"<<a<<endl;
			}
		}
		system("cls");
		cout<<"                                 ͶƱ�����"<<endl;
		for(long long i=1;i<=15;i++)
			if(m[i]==1)
				cout<<"                                 "<<i<<"��"<<"  Ʊ����"<<p[i]<<endl; 
		long long sw,max=-100; 
		for(long long i=1;i<=15;i++)
		{
			if(p[i]>max)
			{
				sw=i;
				max=p[i];
			}
		}
		m[sw]=0;
		cout<<"                                  "<<sw<<"����"<<endl;
		c--;
		cout<<"                              "<<sw<<"�ŵ�������"; 
		if(s[sw]==1)
			cout<<"ɱ��"<<endl;
		else if(s[sw]==2)
			cout<<"Ԥ�Լ�"<<endl;
		else if(s[sw]==3)
			cout<<"ƽ��"<<endl;
		else 
			cout<<"��ʦ"<<endl; 
		if(s[sw]==1&&n!=sr)
		{
			cout<<endl<<"							   "<<sr<<"����ɱ�֣�"; 
			cout<<endl<<"						ɱ����������"<<endl;
			cout<<"                          	��Ϸ����"<<endl;
			return ;
		}
		day++;  
		if(s[n]!=1)   
		{
			for(long long i=1;i<=15;i++)
			if(s[i]==1&&m[i]==1)
				lr=1;
		}
		else
		{
			if(s[n]==1&&c==2)
				lr=0;
		}
		system("pause"); 
		cout<<endl;
		if(m[sr]==0&&n!=sr)
		{
			cout<<endl<<"							   "<<sr<<"����ɱ�֣�"<<endl; 
			cout<<endl<<"						ɱ����������"<<endl;
			cout<<"                          	��Ϸ����"<<endl;
			return ;
		}
	}
	while(m[n]==1&&c>1);
	if(sr==n&&m[n]==1)
	{
		cout<<"								��ɱ���������ˣ�����"<<endl;
	}
	cout<<"                          	��Ϸ����"<<endl;
	return ;
}

void input(){
    cout<<"СС���±�1.1\n";
    cout<<"��������:2022/12/26\n";
    cout<<"�����ַ���ļ���������׺��";
    string s;
    getline(cin,s);
    ifstream fin(s.c_str());
    string t;
    bool flag=0;
    while(getline(fin,t)){
        cout<<t<<endl;
        flag=1;
    }
    if(!flag)cout<<"�ļ�Ϊ�ջ��޸��ļ�\n";
    cout<<"��Enter����";
    getchar();
}
	long long i=1,e,o1=0;
	long double o,f=1,k=0,j=0,g=70,n=350,g11=5,n1=50,uiu=0;
	string ti; 
int sz1;
void shezhi(){
	system("cls");
	cout<<"1.�ı���ɫ\n\n";
	cout<<"2.��������\n";
	cout<<"3.ʵ������\n";
	cout<<"���룺";
	cin>>sz1;
	
} 
string Time2Str()

{

    time_t tm;

    time(&tm); //��ȡtime_t���͵ĵ�ǰʱ��

    char tmp[64];

    strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&tm));

    return tmp;

}
POINT p;
HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
HWND h=GetForegroundWindow();
CONSOLE_FONT_INFO consoleCurrentFont;

void printf_red(const char *s)
{
    printf("\033[0m\033[1;2m%s\033[0m", s);
}

void printf_green(const char *s)
{
    printf("\033[0m\033[1;32m%s\033[0m", s);
}

void printf_yellow(const char *s)
{
    printf("\033[0m\033[1;33m%s\033[0m", s);
}

void printf_blue(const char *s)
{
    printf("\033[0m\033[1;34m%s\033[0m", s);
}

void printf_pink(const char *s)
{
    printf("\033[0m\033[1;35m%s\033[0m", s);
}

void printf_cyan(const char *s)
{
    printf("\033[0m\033[1;36m%s\033[0m", s);
}

int  cx   =    GetSystemMetrics(    SM_CXSCREEN   );   
int  cy   =    GetSystemMetrics(    SM_CYSCREEN   );
VOID SetTitle(LPCSTR lpTitle) {
 SetConsoleTitle(lpTitle);
}
void hide_cursor()//���ع��
{
HANDLE h_GAME =GetStdHandle(STD_OUTPUT_HANDLE);
CONSOLE_CURSOR_INFO cursor_info;
GetConsoleCursorInfo(h_GAME,&cursor_info);
cursor_info.bVisible=false;
SetConsoleCursorInfo(h_GAME,&cursor_info);
}
void show_cursor()//��ʾ���
{
HANDLE h_GAME =GetStdHandle(STD_OUTPUT_HANDLE);
CONSOLE_CURSOR_INFO cursor_info;
GetConsoleCursorInfo(h_GAME,&cursor_info);
cursor_info.bVisible=true;
SetConsoleCursorInfo(h_GAME,&cursor_info);
}
void HideCursor()
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_CURSOR_INFO CursorInfo;
	GetConsoleCursorInfo(handle, &CursorInfo);//��ȡ����̨�����Ϣ
	CursorInfo.bVisible = false; //���ؿ���̨���
	SetConsoleCursorInfo(handle, &CursorInfo);//���ÿ���̨���״̬
}
VOID KillConsoleCloseButton(VOID) {
 DeleteMenu(GetSystemMenu(GetConsoleWindow(), FALSE), 
                          SC_CLOSE, MF_DISABLED);
 DrawMenuBar(GetConsoleWindow());
}
void full_screen()
{   
    HWND hwnd = GetForegroundWindow();
    int cx = GetSystemMetrics(SM_CXSCREEN);           
    int cy = GetSystemMetrics(SM_CYSCREEN);            

    LONG l_WinStyle = GetWindowLong(hwnd,GWL_STYLE);   
    
    SetWindowLong(hwnd,GWL_STYLE,(l_WinStyle | WS_POPUP | WS_MAXIMIZE) & ~WS_CAPTION & ~WS_THICKFRAME & ~WS_BORDER);

    SetWindowPos(hwnd, HWND_TOP, 0, 0, cx, cy, 0);
}


int setfontsize(int x, int y) { //���������С
	CONSOLE_FONT_INFOEX cfi;
	cfi.cbSize = sizeof(cfi);
	cfi.nFont = 0;
	cfi.dwFontSize.X = x;
	cfi.dwFontSize.Y = y;
	cfi.FontFamily = FF_DONTCARE;
	cfi.FontWeight = 400;
	wcscpy(cfi.FaceName, L"NSimSun");
}
void init() {
	SetWindowPos(GetConsoleWindow(), HWND_TOPMOST, -4, 173, 53, 54, SWP_NOSIZE);
	DWORD mode;
	GetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), &mode);
 	mode &= ~ENABLE_QUICK_EDIT_MODE;
	SetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), mode);
	SetWindowLong(GetConsoleWindow(), GWL_STYLE, GetWindowLong(GetConsoleWindow(), GWL_STYLE) & ~WS_CAPTION);
}

void clear(){
    system("cls");
    clear_cin();
}
void ert(){
    MessageBeep(MB_ICONERROR);
}
void output(){
    cout<<"���±�(ת����https://wenda.codingtang.com/questions/22013/)\n";
    cout<<"��������:2022/12/26\n";
    cout<<"��Ctrl+Zֹͣ����\n";
    while(getline(cin,t)){
        s+=t+'\n';
    }
    cin.clear();
    cout<<"\n�ļ�Ŀ¼��";
    string a;
    getline(cin,a);
    cout<<"\n�ļ���(�Ӻ�׺��):";
    string r;
    getline(cin,r);
    a+=r;
    //cout<<"�ļ���+Ŀ¼:"<<a;
    FILE* fp=fopen(a.c_str(),"w");
    fprintf(fp,s.c_str());
    fclose(fp);
    cout<<"д����ɣ�\n��Enter����";
    getchar();
}

void vm(){
	system("color 07");
		ShowScrollBar(GetConsoleWindow(), SB_VERT, 0);
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n press anywere to enter BIOS...";
	Sleep(3000); 
	system("cls");
	for(int i=60;i>=1;i--){
		cout<<"Ready in "<<i<<" Seconds"; 
		Sleep(100);
	system("cls");
	}
		hide_cursor(); 
	cout<<"The virtual machine is ready!";
	MessageBeep(MB_ICONINFORMATION);
	Sleep(1000);
	system("cls");
	HideCursor();
	system("color 01"); 
	for(int i=1;i<=windows11kj;i++){
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                               ....."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                               .... ."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                               ... .  ."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                               .. .  .  ."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                               . .  .  .."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                                .   . ..."; 
		Sleep(500);
		system("cls");
		cout<<"\n\n\n\n\n\n\n";
		cout<<"                                  �� ��\n";
		cout<<"                                  �� ��\n\n";
		cout<<"                                    . ...."; 
		Sleep(500);
		system("cls");
	}
	
	MessageBeep(MB_ICONINFORMATION);
	Sleep(2000);
		while(1) {  
		
		string atime=Time2Str();
		cout<<"tips:��񰴾Ϳ��Ե���Ӧ�� \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
		cout<<"______________________________________________________________________\n";
		cout<<"�� ��                                                "<<atime.c_str()<<"\n";
		cout<<"�� ��                                               ";                       			//ѭ�����
		if(KEY_DOWN(VK_LBUTTON))){  			//����������
			POINT p;
			GetCursorPos(&p);
			ScreenToClient(h,&p);               //��ȡ����ڴ����ϵ�λ��
			GetCurrentConsoleFont(hOutput, FALSE, &consoleCurrentFont); //��ȡ������Ϣ
			int x=p.x/=consoleCurrentFont.dwFontSize.X;
			int y=p.y/=consoleCurrentFont.dwFontSize.Y;
			if(1){
				system("cls");
				cout<<"tips:��񰴾Ϳ��Ե���Ӧ�� \n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
		cout<<"______________________________________________________________________\n";
		cout<<"����                                               "<<atime.c_str()<<"\n";
		cout<<"����                                               "; 
		Sleep(1000);                      			
				system("cls");
				Sleep(1000);
				cout<<"���ڼ��ؿ�ʼ�˵�������"; 
				Sleep(1000); 
				system("cls"); 
				cout<<"��ʼ\n\n";
				cout<<"___________________   ________________\n"; 
				cout<<"|                 |   |              |\n";
				cout<<"|                 |   |              |\n";
				cout<<"|    1.���±�     |   |   2.����     |\n";
				cout<<"|                 |   |              |\n";
				cout<<"|_________________|   |______________|\n";
				cout<<"____________   _______________________\n";
				cout<<"|          |  |                      |\n";
				cout<<"|  3.�ػ�  |  |     4.�����         |\n";
				cout<<"|__________|  |______________________|\n";
				cout<<"____________________  ________________\n";
				cout<<"|                  |  |              |\n";
				cout<<"| 5.����ɱ(��ԭ��) |  | 6.XACRAFT 3.3|\n";
				cout<<"|__________________|  |______________|\n";
				cout<<"\n ������(��겻��ʾ)��"; 
				cin>>choose;
				if(choose==1){
					system("title ���±�");
					system("cls");
					cout<<"��ӭ�������±���";
					Sleep(1000);
					system("cls");
					cout<<"������±�365�ɽ����߼���!\n______________________________________________________________________";
					Sleep(1000);
					system("cls");
					system("title СС���±�1.1 Build 1100");
				    while(1){
				        clear();
				        cout<<"СС���±���ת�ذ棩\n";
				        cout<<"��������:"<<atime.c_str()<<"\n";
				        cout<<"____________\n"; 
				        cout<<"|1.д���ļ�|\n";
						cout<<"|2.��ȡ�ļ�|\n";
						cout<<"|3.�汾��  |\n";
						cout<<"|4.�˳�    |\n";
						cout<<"|__________|\n";
				        string s;
				        getline(cin,s);
				        clear();
				        if(s=="1"||s=="1.д���ļ�"||s=="д���ļ�"){
				            output();
				        }
				        else if(s=="2"||s=="2.�����ļ�"||s=="�����ļ�"){
				            input();
				        }
				        else if(s=="3"||s=="3.�汾��"||s=="�汾��"){
				            cout<<"СС���±�1.1 Build 1100\n";
				            cout<<"��������:"<<atime.c_str()<<"\n";
				            cout<<"��Enter����";
				            getchar(); 
				        }
				        else if(s=="4"||s=="4.�˳�"||s=="�˳�")break;
				        else{
				            ert();
				        }
				    } 
				}
				if(choose==2){
					shezhi();
					if(sz1==1){
						system("cls");
						cout<<"BUG���࣡��������������";
						Sleep(1000);
						system("mode con cols=25 lines=25");
						system("cls");
					    cout<<"0.��ɫ      8.��ɫ\n1.��ɫ      9.����ɫ\n2.��ɫ      10.����ɫ\n3.ǳ��ɫ    11.��ǳ��ɫ\n";
					    cout<<"4.��ɫ      12.����ɫ\n5.��ɫ      13.����ɫ\n6.��ɫ      14.����ɫ\n7.��ɫ      ���������֣�����ɫ\n";
					    cout<<"������ɫ��";
					    cin>>i;
						system("cls");
					    cout<<"0.��ɫ      8.��ɫ\n1.��ɫ      9.����ɫ\n2.��ɫ      10.����ɫ\n3.ǳ��ɫ    11.��ǳ��ɫ\n";
					    cout<<"4.��ɫ      12.����ɫ\n5.��ɫ      13.����ɫ\n6.��ɫ      14.����ɫ\n7.��ɫ      ���������֣�����ɫ\n";
					    cout<<"������ɫ��";
					    cin>>e;
						if(e==0){
							if(i==0){
								system("color 00");
							}else if(i==1){
								system("color 10");
							}else if(i==2){
								system("color 20");
							}else if(i==3){
								system("color 30");
							}else if(i==4){
								system("color 40");
							}else if(i==5){
								system("color 50");
							}else if(i==6){
								system("color 60");
							}else if(i==7){
								system("color 70");
							}else if(i==8){
								system("color 80");
							}else if(i==9){
								system("color 90");
							}else if(i==10){
								system("color a0");
							}else if(i==11){
								system("color b0");
							}else if(i==12){
								system("color c0");
							}else if(i==13){
								system("color d0");
							}else if(i==14){
								system("color e0");
							}else{
								system("color f0");
							}
							}else if(e==1){
								if(i==0){
								system("color 01");
							}else if(i==1){
								system("color 11");
							}else if(i==2){
								system("color 21");
							}else if(i==3){
								system("color 31");
							}else if(i==4){
								system("color 41");
							}else if(i==5){
								system("color 51");
							}else if(i==6){
								system("color 61");
							}else if(i==7){
								system("color 71");
							}else if(i==8){
								system("color 81");
							}else if(i==9){
								system("color 91");
							}else if(i==10){
								system("color a1");
							}else if(i==11){
								system("color b1");
							}else if(i==12){
								system("color c1");
							}else if(i==13){
								system("color d1");
							}else if(i==14){
								system("color e1");
							}else{
								system("color f1");
							}
						}else if(e==2){
							if(i==0){
							system("color 02");
						}else if(i==1){
							system("color 12");
						}else if(i==2){
							system("color 22");
						}else if(i==3){
							system("color 32");
						}else if(i==4){
							system("color 42");
						}else if(i==5){
							system("color 52");
						}else if(i==6){
							system("color 62");
						}else if(i==7){
							system("color 72");
						}else if(i==8){
							system("color 82");
						}else if(i==9){
							system("color 92");
						}else if(i==10){
							system("color a2");
						}else if(i==11){
							system("color b2");
						}else if(i==12){
							system("color c2");
						}else if(i==13){
							system("color d2");
						}else if(i==14){
							system("color e2");
						}else{
							system("color f2");
						}
						}else if(e==3){
							if(i==0){
							system("color 03");
						}else if(i==1){
							system("color 13");
						}else if(i==2){
							system("color 23");
						}else if(i==3){
							system("color 33");
						}else if(i==4){
							system("color 43");
						}else if(i==5){
							system("color 53");
						}else if(i==6){
							system("color 63");
						}else if(i==7){
							system("color 73");
						}else if(i==8){
							system("color 83");
						}else if(i==9){
							system("color 93");
						}else if(i==10){
							system("color a3");
						}else if(i==11){
							system("color b3");
						}else if(i==12){
							system("color c3");
						}else if(i==13){
							system("color d3");
						}else if(i==14){
							system("color e3");
						}else{
							system("color f3");
						}
						}else if(e==4){
							if(i==0){
							system("color 04");
						}else if(i==1){
							system("color 14");
						}else if(i==2){
							system("color 24");
						}else if(i==3){
							system("color 34");
						}else if(i==4){
							system("color 44");
						}else if(i==5){
							system("color 54");
						}else if(i==6){
							system("color 64");
						}else if(i==7){
							system("color 74");
						}else if(i==8){
							system("color 84");
						}else if(i==9){
							system("color 94");
						}else if(i==10){
							system("color a4");
						}else if(i==11){
							system("color b4");
						}else if(i==12){
							system("color c4");
						}else if(i==13){
							system("color d4");
						}else if(i==14){
							system("color e4");
						}else{
							system("color f4");
						}
						}else if(e==5){
							if(i==0){
							system("color 05");
						}else if(i==1){
							system("color 15");
						}else if(i==2){
							system("color 25");
						}else if(i==3){
							system("color 35");
						}else if(i==4){
							system("color 45");
						}else if(i==5){
							system("color 55");
						}else if(i==6){
							system("color 65");
						}else if(i==7){
							system("color 75");
						}else if(i==8){
							system("color 85");
						}else if(i==9){
							system("color 95");
						}else if(i==10){
							system("color a5");
						}else if(i==11){
							system("color b5");
						}else if(i==12){
							system("color c5");
						}else if(i==13){
							system("color d5");
						}else if(i==14){
							system("color e5");
						}else{
							system("color f5");
						}
						}else if(e==6){
							if(i==0){
							system("color 06");
						}else if(i==1){
							system("color 16");
						}else if(i==2){
							system("color 26");
						}else if(i==3){
							system("color 36");
						}else if(i==4){
							system("color 46");
						}else if(i==5){
							system("color 56");
						}else if(i==6){
							system("color 66");
						}else if(i==7){
							system("color 76");
						}else if(i==8){
							system("color 86");
						}else if(i==9){
							system("color 96");
						}else if(i==10){
							system("color a6");
						}else if(i==11){
							system("color b6");
						}else if(i==12){
							system("color c6");
						}else if(i==13){
							system("color d6");
						}else if(i==14){
							system("color e6");
						}else{
							system("color f6");
						}
						}else if(e==7){
							if(i==0){
							system("color 07");
						}else if(i==1){
							system("color 17");
						}else if(i==2){
							system("color 27");
						}else if(i==3){
							system("color 37");
						}else if(i==4){
							system("color 47");
						}else if(i==5){
							system("color 57");
						}else if(i==6){
							system("color 67");
						}else if(i==7){
							system("color 77");
						}else if(i==8){
							system("color 87");
						}else if(i==9){
							system("color 97");
						}else if(i==10){
							system("color a7");
						}else if(i==11){
							system("color b7");
						}else if(i==12){
							system("color c7");
						}else if(i==13){
							system("color d7");
						}else if(i==14){
							system("color e7");
						}else{
							system("color f7");
						}
						}else if(e==8){
							if(i==0){
							system("color 08");
						}else if(i==1){
							system("color 18");
						}else if(i==2){
							system("color 28");
						}else if(i==3){
							system("color 38");
						}else if(i==4){
							system("color 48");
						}else if(i==5){
							system("color 58");
						}else if(i==6){
							system("color 68");
						}else if(i==7){
							system("color 78");
						}else if(i==8){
							system("color 88");
						}else if(i==9){
							system("color 98");
						}else if(i==10){
							system("color a8");
						}else if(i==11){
							system("color b8");
						}else if(i==12){
							system("color c8");
						}else if(i==13){
							system("color d8");
						}else if(i==14){
							system("color e8");
						}else{
							system("color f8");
						}
						}else if(e==9){
							if(i==0){
							system("color 09");
						}else if(i==1){
							system("color 19");
						}else if(i==2){
							system("color 29");
						}else if(i==3){
							system("color 39");
						}else if(i==4){
							system("color 49");
						}else if(i==5){
							system("color 59");
						}else if(i==6){
							system("color 69");
						}else if(i==7){
							system("color 79");
						}else if(i==8){
							system("color 89");
						}else if(i==9){
							system("color 99");
						}else if(i==10){
							system("color a9");
						}else if(i==11){
							system("color b9");
						}else if(i==12){
							system("color c9");
						}else if(i==13){
							system("color d9");
						}else if(i==14){
							system("color e9");
						}else{
							system("color f9");
						}
						}else if(e==10){
							if(i==0){
							system("color 0a");
						}else if(i==1){
							system("color 1a");
						}else if(i==2){
							system("color 2a");
						}else if(i==3){
							system("color 3a");
						}else if(i==4){
							system("color 4a");
						}else if(i==5){
							system("color 5a");
						}else if(i==6){
							system("color 6a");
						}else if(i==7){
							system("color 7a");
						}else if(i==8){
							system("color 8a");
						}else if(i==9){
							system("color 9a");
						}else if(i==10){
							system("color aa");
						}else if(i==11){
							system("color ba");
						}else if(i==12){
							system("color ca");
						}else if(i==13){
							system("color da");
						}else if(i==14){
							system("color ea");
						}else{
							system("color fa");
						}
						}else if(e==11){
							if(i==0){
							system("color 0b");
						}else if(i==1){
							system("color 1b");
						}else if(i==2){
							system("color 2b");
						}else if(i==3){
							system("color 3b");
						}else if(i==4){
							system("color 4b");
						}else if(i==5){
							system("color 5b");
						}else if(i==6){
							system("color 6b");
						}else if(i==7){
							system("color 7b");
						}else if(i==8){
							system("color 8b");
						}else if(i==9){
							system("color 9b");
						}else if(i==10){
							system("color ab");
						}else if(i==11){
							system("color bb");
						}else if(i==12){
							system("color cb");
						}else if(i==13){
							system("color db");
						}else if(i==14){
							system("color eb");
						}else{
							system("color fb");
						}
						}else if(e==12){
							if(i==0){
							system("color 0c");
						}else if(i==1){
							system("color 1c");
						}else if(i==2){
							system("color 2c");
						}else if(i==3){
							system("color 3c");
						}else if(i==4){
							system("color 4c");
						}else if(i==5){
							system("color 5c");
						}else if(i==6){
							system("color 6c");
						}else if(i==7){
							system("color 7c");
						}else if(i==8){
							system("color 8c");
						}else if(i==9){
							system("color 9c");
						}else if(i==10){
							system("color ac");
						}else if(i==11){
							system("color bc");
						}else if(i==12){
							system("color cc");
						}else if(i==13){
							system("color dc");
						}else if(i==14){
							system("color ec");
						}else{
							system("color fc");
						}
						}else if(e==13){
							if(i==0){
							system("color 0d");
						}else if(i==1){
							system("color 1d");
						}else if(i==2){
							system("color 2d");
						}else if(i==3){
							system("color 3d");
						}else if(i==4){
							system("color 4d");
						}else if(i==5){
							system("color 5d");
						}else if(i==6){
							system("color 6d");
						}else if(i==7){
							system("color 7d");
						}else if(i==8){
							system("color 8d");
						}else if(i==9){
							system("color 9d");
						}else if(i==10){
							system("color ad");
						}else if(i==11){
							system("color bd");
						}else if(i==12){
							system("color cd");
						}else if(i==13){
							system("color dd");
						}else if(i==14){
							system("color ed");
						}else{
							system("color fd");
						}
						}else if(e==14){
							if(i==0){
							system("color 0e");
						}else if(i==1){
							system("color 1e");
						}else if(i==2){
							system("color 2e");
						}else if(i==3){
							system("color 3e");
						}else if(i==4){
							system("color 4e");
						}else if(i==5){
							system("color 5e");
						}else if(i==6){
							system("color 6e");
						}else if(i==7){
							system("color 7e");
						}else if(i==8){
							system("color 8e");
						}else if(i==9){
							system("color 9e");
						}else if(i==10){
							system("color ae");
						}else if(i==11){
							system("color be");
						}else if(i==12){
							system("color ce");
						}else if(i==13){
							system("color de");
						}else if(i==14){
							system("color ee");
						}else{
							system("color fe");
						}
						}else{
							if(i==0){
								system("color 0f");
							}else if(i==1){
								system("color 1f");
							}else if(i==2){
								system("color 2f");
							}else if(i==3){
								system("color 3f");
							}else if(i==4){
								system("color 4f");
							}else if(i==5){
								system("color 5f");
							}else if(i==6){
								system("color 6f");
							}else if(i==7){
								system("color 7f");
							}else if(i==8){
								system("color 8f");
							}else if(i==9){
								system("color 9f");
							}else if(i==10){
								system("color af");
							}else if(i==11){
								system("color bf");
							}else if(i==12){
								system("color cf");
							}else if(i==13){
								system("color df");
							}else if(i==14){
								system("color ef");
							}else{
								system("color ff");
							}
						}
					}
					if(sz1==2){
						system("cls");
						cout<<"1.����1����ʱ��\n"; 
						cout<<"2.�˳�\n"; 
						cin>>kj;
						if(kj==1){
							cout<<"���뿪��ʱ�䣺"<<windows11kj;
							cin>>windows11kj;
							cout<<"�ɹ�����"; 
						}
					} 
				}
				if(choose==4){
					system("cls");
					vm();
				} 
				if(choose==3){
					system("cls");
					cout<<"________________________\n"; 
					cout<<"|      1.���Թػ�      |\n";
					cout<<"|2.�˵�ϵͳ���̣���ѡ��|\n";
					cout<<"|      3.��������      |\n";
					cout<<"|      4.����ע��      |\n";
					cout<<"|______________________|\n";
					cout<<"�����룺";
					cin>>guanji;
					if(guanji==1){
						system("shutdown -s -t 6");
					}
					if(guanji==2){
						HWND hwnd=GetForegroundWindow();
    					ShowWindow(hwnd,SW_HIDE);
					}	 
					if(guanji==3){
						system("shutdown -r -t 6");
					}
					if(guanji==4){
						system("logoff");
					}
				} 
				if(choose==5){
					srand((int)time(0));  
						char a='1';
						while(1)
						{
							system("cls");
							cout<<"                                   			ɱ����Ϸ"<<endl;
							cout<<"------------------------------------------------------------------------------------------------------------------------";
							cout<<"                                 		   1.��ʼ��Ϸ"<<endl;
							cout<<"                                		  2.�鿴��Ϸ����"<<endl;
							a=getch();
							if(a=='1')
							{
								cout<<"                                 		   1. 15�˳�"<<endl;
								cout<<"                          			2. 30������ս(10����)<�����ڴ�>"<<endl;
								a='2';
								while(a=='2')
								{
									a=getch();
									switch(a)
									{
										case '1':
											brc();
										break;
									}
									if(a=='1')
										break;
								}
								if(a=='1')
									break;
							}
							else if(a=='2')
							{
								cout<<"ɱ�֣�ÿ�����ϵ�ʱ���ʹ��ɱ��Ȩɱ��һ��"<<endl;//1
								cout<<"Ԥ�Լң�ÿ�����Ͽ���֪��һ���˵�����"<<endl;//2 
								cout<<"ƽ���޼���,�������ƽ��ʱ���ڵ�5��ӵ��1.5Ʊ��ͶƱȨ"<<endl;//3
								cout<<"���ˣ������ݽ�����30�����־��У�������ɴ���һ��"<<endl; 
								cout<<"ͶƱϸ��\n����Ϸ�г���������ȫ���ɳ���AI�˹����棩"<<endl;
								cout<<"Ԥ�Լ����Ԥ�Ե�ɱ�ֽ�һֱ����ͶƱ�����Ԥ�Ե����˽���Զ�������ͶƱ"<<endl;
								cout<<"ƽ��Ͷ��һ�����϶���ͶƱ������"<<endl;
								cout<<"********���úó���AI��Ϸ�����ҳ�ɱ��**********"<<endl;
								system("pause");
							}
						}

				}
				if(choose==6){
					system("cls");
					Sleep(1000);
					system("start xacraft666.exe");
				} 
			}
		}   
		Sleep(1000);
		system("cls");
	}


}
int main(){
		ShowScrollBar(GetConsoleWindow(), SB_VERT, 0);
    		init();
			system("mode con cols=50 lines=50");
			system("color 47");
			Sleep(10);
			system("mode con cols=51 lines=51");
			Sleep(10);
			system("mode con cols=52 lines=52");
			Sleep(10);
			system("mode con cols=53 lines=53");
			Sleep(10);
			system("mode con cols=53 lines=29");
			Sleep(10);
			int choose;
			system("cls");
				Sleep(1000);
				SetWindowPos(GetConsoleWindow(), HWND_TOPMOST, -4, 173, 53, 54, SWP_NOSIZE);
				cout<<"���ڼ��ؿ�ʼ�˵�������"; 
				Sleep(1000); 
				
				HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
				system("cls"); 
				cout<<"��ʼ\n\n";
				cout<<"___________________   ________________\n"; 
				cout<<"|                 |   |              |\n";
				cout<<"|                 |   |              |\n";
				cout<<"|    1.���±�     |   |   2.����     |\n";
				cout<<"|                 |   |              |\n";
				cout<<"|_________________|   |______________|\n";
				cout<<"____________   _______________________\n";
				cout<<"|          |  |                      |\n";
				cout<<"|  3.�ػ�  |  |     4.�����         |\n";
				cout<<"|__________|  |______________________|\n";
				cout<<"____________________  ________________\n";
				cout<<"|                  |  |              |\n";
				cout<<"| 5.����ɱ(��ԭ��) |  | 6.XACRAFT 3.3|\n";
				cout<<"|__________________|  |______________|\n";
				cout<<" __________    ______________________ \n";
				cout<<"|          |  |                      |\n";
				cout<<"| 7.������ |  |   8.HAPPYNEWYEAR     |\n";
				cout<<"|          |  |    �d(�R���Q*)o      |\n";
				cout<<"|__________|  |______________________|\n";
				cout<<"\n ������(��겻��ʾ)��"; 
				cin>>choose;
				if(choose==1){
					system("title ���±�");
					system("cls");
					cout<<"��ӭ�������±���";
					Sleep(1000);
					system("cls");
					cout<<"������±�365�ɽ����߼���!\n______________________________________________________________________";
					Sleep(1000);
					system("cls");
					system("title СС���±�1.1 Build 1100");
				    while(1){
				        clear();
				        cout<<"СС���±���ת�ذ棩\n";
				        cout<<"��������:"<<"û��"<<"\n";
				        cout<<"____________\n"; 
				        cout<<"|1.д���ļ�|\n";
						cout<<"|2.��ȡ�ļ�|\n";
						cout<<"|3.�汾��  |\n";
						cout<<"|4.�˳�    |\n";
						cout<<"|__________|\n";
				        string s;
				        getline(cin,s);
				        clear();
				        if(s=="1"||s=="1.д���ļ�"||s=="д���ļ�"){
				            output();
				        }
				        else if(s=="2"||s=="2.�����ļ�"||s=="�����ļ�"){
				            input();
				        }
				        else if(s=="3"||s=="3.�汾��"||s=="�汾��"){
				            cout<<"СС���±�1.1 Build 1100\n";
				            cout<<"��������:"<<"1"<<"\n";
				            cout<<"��Enter����";
				            getchar(); 
				        }
				        else if(s=="4"||s=="4.�˳�"||s=="�˳�")break;
				        else{
				            ert();
				        }
				    } 
				}
				if(choose==2){
					shezhi();
					if(sz1==1){
						system("cls");
						cout<<"BUG���࣡��������������";
						Sleep(1000);
						system("mode con cols=25 lines=25");
						system("cls");
					    cout<<"0.��ɫ      8.��ɫ\n1.��ɫ      9.����ɫ\n2.��ɫ      10.����ɫ\n3.ǳ��ɫ    11.��ǳ��ɫ\n";
					    cout<<"4.��ɫ      12.����ɫ\n5.��ɫ      13.����ɫ\n6.��ɫ      14.����ɫ\n7.��ɫ      ���������֣�����ɫ\n";
					    cout<<"������ɫ��";
					    cin>>i;
						system("cls");
					    cout<<"0.��ɫ      8.��ɫ\n1.��ɫ      9.����ɫ\n2.��ɫ      10.����ɫ\n3.ǳ��ɫ    11.��ǳ��ɫ\n";
					    cout<<"4.��ɫ      12.����ɫ\n5.��ɫ      13.����ɫ\n6.��ɫ      14.����ɫ\n7.��ɫ      ���������֣�����ɫ\n";
					    cout<<"������ɫ��";
					    cin>>e;
						if(e==0){
							if(i==0){
								system("color 00");
							}else if(i==1){
								system("color 10");
							}else if(i==2){
								system("color 20");
							}else if(i==3){
								system("color 30");
							}else if(i==4){
								system("color 40");
							}else if(i==5){
								system("color 50");
							}else if(i==6){
								system("color 60");
							}else if(i==7){
								system("color 70");
							}else if(i==8){
								system("color 80");
							}else if(i==9){
								system("color 90");
							}else if(i==10){
								system("color a0");
							}else if(i==11){
								system("color b0");
							}else if(i==12){
								system("color c0");
							}else if(i==13){
								system("color d0");
							}else if(i==14){
								system("color e0");
							}else{
								system("color f0");
							}
							}else if(e==1){
								if(i==0){
								system("color 01");
							}else if(i==1){
								system("color 11");
							}else if(i==2){
								system("color 21");
							}else if(i==3){
								system("color 31");
							}else if(i==4){
								system("color 41");
							}else if(i==5){
								system("color 51");
							}else if(i==6){
								system("color 61");
							}else if(i==7){
								system("color 71");
							}else if(i==8){
								system("color 81");
							}else if(i==9){
								system("color 91");
							}else if(i==10){
								system("color a1");
							}else if(i==11){
								system("color b1");
							}else if(i==12){
								system("color c1");
							}else if(i==13){
								system("color d1");
							}else if(i==14){
								system("color e1");
							}else{
								system("color f1");
							}
						}else if(e==2){
							if(i==0){
							system("color 02");
						}else if(i==1){
							system("color 12");
						}else if(i==2){
							system("color 22");
						}else if(i==3){
							system("color 32");
						}else if(i==4){
							system("color 42");
						}else if(i==5){
							system("color 52");
						}else if(i==6){
							system("color 62");
						}else if(i==7){
							system("color 72");
						}else if(i==8){
							system("color 82");
						}else if(i==9){
							system("color 92");
						}else if(i==10){
							system("color a2");
						}else if(i==11){
							system("color b2");
						}else if(i==12){
							system("color c2");
						}else if(i==13){
							system("color d2");
						}else if(i==14){
							system("color e2");
						}else{
							system("color f2");
						}
						}else if(e==3){
							if(i==0){
							system("color 03");
						}else if(i==1){
							system("color 13");
						}else if(i==2){
							system("color 23");
						}else if(i==3){
							system("color 33");
						}else if(i==4){
							system("color 43");
						}else if(i==5){
							system("color 53");
						}else if(i==6){
							system("color 63");
						}else if(i==7){
							system("color 73");
						}else if(i==8){
							system("color 83");
						}else if(i==9){
							system("color 93");
						}else if(i==10){
							system("color a3");
						}else if(i==11){
							system("color b3");
						}else if(i==12){
							system("color c3");
						}else if(i==13){
							system("color d3");
						}else if(i==14){
							system("color e3");
						}else{
							system("color f3");
						}
						}else if(e==4){
							if(i==0){
							system("color 04");
						}else if(i==1){
							system("color 14");
						}else if(i==2){
							system("color 24");
						}else if(i==3){
							system("color 34");
						}else if(i==4){
							system("color 44");
						}else if(i==5){
							system("color 54");
						}else if(i==6){
							system("color 64");
						}else if(i==7){
							system("color 74");
						}else if(i==8){
							system("color 84");
						}else if(i==9){
							system("color 94");
						}else if(i==10){
							system("color a4");
						}else if(i==11){
							system("color b4");
						}else if(i==12){
							system("color c4");
						}else if(i==13){
							system("color d4");
						}else if(i==14){
							system("color e4");
						}else{
							system("color f4");
						}
						}else if(e==5){
							if(i==0){
							system("color 05");
						}else if(i==1){
							system("color 15");
						}else if(i==2){
							system("color 25");
						}else if(i==3){
							system("color 35");
						}else if(i==4){
							system("color 45");
						}else if(i==5){
							system("color 55");
						}else if(i==6){
							system("color 65");
						}else if(i==7){
							system("color 75");
						}else if(i==8){
							system("color 85");
						}else if(i==9){
							system("color 95");
						}else if(i==10){
							system("color a5");
						}else if(i==11){
							system("color b5");
						}else if(i==12){
							system("color c5");
						}else if(i==13){
							system("color d5");
						}else if(i==14){
							system("color e5");
						}else{
							system("color f5");
						}
						}else if(e==6){
							if(i==0){
							system("color 06");
						}else if(i==1){
							system("color 16");
						}else if(i==2){
							system("color 26");
						}else if(i==3){
							system("color 36");
						}else if(i==4){
							system("color 46");
						}else if(i==5){
							system("color 56");
						}else if(i==6){
							system("color 66");
						}else if(i==7){
							system("color 76");
						}else if(i==8){
							system("color 86");
						}else if(i==9){
							system("color 96");
						}else if(i==10){
							system("color a6");
						}else if(i==11){
							system("color b6");
						}else if(i==12){
							system("color c6");
						}else if(i==13){
							system("color d6");
						}else if(i==14){
							system("color e6");
						}else{
							system("color f6");
						}
						}else if(e==7){
							if(i==0){
							system("color 07");
						}else if(i==1){
							system("color 17");
						}else if(i==2){
							system("color 27");
						}else if(i==3){
							system("color 37");
						}else if(i==4){
							system("color 47");
						}else if(i==5){
							system("color 57");
						}else if(i==6){
							system("color 67");
						}else if(i==7){
							system("color 77");
						}else if(i==8){
							system("color 87");
						}else if(i==9){
							system("color 97");
						}else if(i==10){
							system("color a7");
						}else if(i==11){
							system("color b7");
						}else if(i==12){
							system("color c7");
						}else if(i==13){
							system("color d7");
						}else if(i==14){
							system("color e7");
						}else{
							system("color f7");
						}
						}else if(e==8){
							if(i==0){
							system("color 08");
						}else if(i==1){
							system("color 18");
						}else if(i==2){
							system("color 28");
						}else if(i==3){
							system("color 38");
						}else if(i==4){
							system("color 48");
						}else if(i==5){
							system("color 58");
						}else if(i==6){
							system("color 68");
						}else if(i==7){
							system("color 78");
						}else if(i==8){
							system("color 88");
						}else if(i==9){
							system("color 98");
						}else if(i==10){
							system("color a8");
						}else if(i==11){
							system("color b8");
						}else if(i==12){
							system("color c8");
						}else if(i==13){
							system("color d8");
						}else if(i==14){
							system("color e8");
						}else{
							system("color f8");
						}
						}else if(e==9){
							if(i==0){
							system("color 09");
						}else if(i==1){
							system("color 19");
						}else if(i==2){
							system("color 29");
						}else if(i==3){
							system("color 39");
						}else if(i==4){
							system("color 49");
						}else if(i==5){
							system("color 59");
						}else if(i==6){
							system("color 69");
						}else if(i==7){
							system("color 79");
						}else if(i==8){
							system("color 89");
						}else if(i==9){
							system("color 99");
						}else if(i==10){
							system("color a9");
						}else if(i==11){
							system("color b9");
						}else if(i==12){
							system("color c9");
						}else if(i==13){
							system("color d9");
						}else if(i==14){
							system("color e9");
						}else{
							system("color f9");
						}
						}else if(e==10){
							if(i==0){
							system("color 0a");
						}else if(i==1){
							system("color 1a");
						}else if(i==2){
							system("color 2a");
						}else if(i==3){
							system("color 3a");
						}else if(i==4){
							system("color 4a");
						}else if(i==5){
							system("color 5a");
						}else if(i==6){
							system("color 6a");
						}else if(i==7){
							system("color 7a");
						}else if(i==8){
							system("color 8a");
						}else if(i==9){
							system("color 9a");
						}else if(i==10){
							system("color aa");
						}else if(i==11){
							system("color ba");
						}else if(i==12){
							system("color ca");
						}else if(i==13){
							system("color da");
						}else if(i==14){
							system("color ea");
						}else{
							system("color fa");
						}
						}else if(e==11){
							if(i==0){
							system("color 0b");
						}else if(i==1){
							system("color 1b");
						}else if(i==2){
							system("color 2b");
						}else if(i==3){
							system("color 3b");
						}else if(i==4){
							system("color 4b");
						}else if(i==5){
							system("color 5b");
						}else if(i==6){
							system("color 6b");
						}else if(i==7){
							system("color 7b");
						}else if(i==8){
							system("color 8b");
						}else if(i==9){
							system("color 9b");
						}else if(i==10){
							system("color ab");
						}else if(i==11){
							system("color bb");
						}else if(i==12){
							system("color cb");
						}else if(i==13){
							system("color db");
						}else if(i==14){
							system("color eb");
						}else{
							system("color fb");
						}
						}else if(e==12){
							if(i==0){
							system("color 0c");
						}else if(i==1){
							system("color 1c");
						}else if(i==2){
							system("color 2c");
						}else if(i==3){
							system("color 3c");
						}else if(i==4){
							system("color 4c");
						}else if(i==5){
							system("color 5c");
						}else if(i==6){
							system("color 6c");
						}else if(i==7){
							system("color 7c");
						}else if(i==8){
							system("color 8c");
						}else if(i==9){
							system("color 9c");
						}else if(i==10){
							system("color ac");
						}else if(i==11){
							system("color bc");
						}else if(i==12){
							system("color cc");
						}else if(i==13){
							system("color dc");
						}else if(i==14){
							system("color ec");
						}else{
							system("color fc");
						}
						}else if(e==13){
							if(i==0){
							system("color 0d");
						}else if(i==1){
							system("color 1d");
						}else if(i==2){
							system("color 2d");
						}else if(i==3){
							system("color 3d");
						}else if(i==4){
							system("color 4d");
						}else if(i==5){
							system("color 5d");
						}else if(i==6){
							system("color 6d");
						}else if(i==7){
							system("color 7d");
						}else if(i==8){
							system("color 8d");
						}else if(i==9){
							system("color 9d");
						}else if(i==10){
							system("color ad");
						}else if(i==11){
							system("color bd");
						}else if(i==12){
							system("color cd");
						}else if(i==13){
							system("color dd");
						}else if(i==14){
							system("color ed");
						}else{
							system("color fd");
						}
						}else if(e==14){
							if(i==0){
							system("color 0e");
						}else if(i==1){
							system("color 1e");
						}else if(i==2){
							system("color 2e");
						}else if(i==3){
							system("color 3e");
						}else if(i==4){
							system("color 4e");
						}else if(i==5){
							system("color 5e");
						}else if(i==6){
							system("color 6e");
						}else if(i==7){
							system("color 7e");
						}else if(i==8){
							system("color 8e");
						}else if(i==9){
							system("color 9e");
						}else if(i==10){
							system("color ae");
						}else if(i==11){
							system("color be");
						}else if(i==12){
							system("color ce");
						}else if(i==13){
							system("color de");
						}else if(i==14){
							system("color ee");
						}else{
							system("color fe");
						}
						}else{
							if(i==0){
								system("color 0f");
							}else if(i==1){
								system("color 1f");
							}else if(i==2){
								system("color 2f");
							}else if(i==3){
								system("color 3f");
							}else if(i==4){
								system("color 4f");
							}else if(i==5){
								system("color 5f");
							}else if(i==6){
								system("color 6f");
							}else if(i==7){
								system("color 7f");
							}else if(i==8){
								system("color 8f");
							}else if(i==9){
								system("color 9f");
							}else if(i==10){
								system("color af");
							}else if(i==11){
								system("color bf");
							}else if(i==12){
								system("color cf");
							}else if(i==13){
								system("color df");
							}else if(i==14){
								system("color ef");
							}else{
								system("color ff");
							}
						}
					}
					if(sz1==2){
						system("cls");
						cout<<"1.����1����ʱ��\n"; 
						cout<<"2.�˳�\n"; 
						cin>>kj;
						if(kj==1){
							cout<<"���뿪��ʱ�䣺"<<windows11kj;
							cin>>windows11kj;
							cout<<"�ɹ�����"; 
						}
					} 
				}
				if(choose==4){
					system("cls");
					system("title YOS-11 (build 22000.65)");
					HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
					DWORD mode;
					GetConsoleMode(hStdin, &mode);
					mode &= ~ENABLE_QUICK_EDIT_MODE;
					SetConsoleMode(hStdin, mode);
					hide_cursor(); 
					full_screen();
					vm();
				} 
				if(choose==3){
					system("cls");
					cout<<"________________________\n"; 
					cout<<"|      1.���Թػ�      |\n";
					cout<<"|2.�˵�ϵͳ���̣���ѡ��|\n";
					cout<<"|      3.��������      |\n";
					cout<<"|      4.����ע��      |\n";
					cout<<"|______________________|\n";
					cout<<"�����룺";
					cin>>guanji;
					if(guanji==1){
						system("shutdown -s -t 6");
					}
					if(guanji==2){
						HWND hwnd=GetForegroundWindow();
    					ShowWindow(hwnd,SW_HIDE);
					}	 
					if(guanji==3){
						system("shutdown -r -t 6");
					}
					if(guanji==4){
						system("logoff");
					}
				} 
				if(choose==5){
					srand((int)time(0));  
						char a='1';
						while(1)
						{
							system("cls");
							cout<<"                                   			ɱ����Ϸ"<<endl;
							cout<<"------------------------------------------------------------------------------------------------------------------------";
							cout<<"                                 		   1.��ʼ��Ϸ"<<endl;
							cout<<"                                		  2.�鿴��Ϸ����"<<endl;
							a=getch();
							if(a=='1')
							{
								cout<<"                                 		   1. 15�˳�"<<endl;
								cout<<"                          			2. 30������ս(10����)<�����ڴ�>"<<endl;
								a='2';
								while(a=='2')
								{
									a=getch();
									switch(a)
									{
										case '1':
											brc();
										break;
									}
									if(a=='1')
										break;
								}
								if(a=='1')
									break;
							}
							else if(a=='2')
							{
								cout<<"ɱ�֣�ÿ�����ϵ�ʱ���ʹ��ɱ��Ȩɱ��һ��"<<endl;//1
								cout<<"Ԥ�Լң�ÿ�����Ͽ���֪��һ���˵�����"<<endl;//2 
								cout<<"ƽ���޼���,�������ƽ��ʱ���ڵ�5��ӵ��1.5Ʊ��ͶƱȨ"<<endl;//3
								cout<<"���ˣ������ݽ�����30�����־��У�������ɴ���һ��"<<endl; 
								cout<<"ͶƱϸ��\n����Ϸ�г���������ȫ���ɳ���AI�˹����棩"<<endl;
								cout<<"Ԥ�Լ����Ԥ�Ե�ɱ�ֽ�һֱ����ͶƱ�����Ԥ�Ե����˽���Զ�������ͶƱ"<<endl;
								cout<<"ƽ��Ͷ��һ�����϶���ͶƱ������"<<endl;
								cout<<"********���úó���AI��Ϸ�����ҳ�ɱ��**********"<<endl;
								system("pause");
							}
						}

				}
				if(choose==6){
					system("cls");
					Sleep(1000);
					system("start xacraft666.exe");
				} 
				if(choose==7){
					system("start ������.exe");
				} 
				if(choose==8){
					system("start HappyNEWYear.exe");
				} 
				HWND hwnd=GetForegroundWindow();
   				ShowWindow(hwnd,SW_HIDE);
    return 0;
}

