#include <bits/stdc++.h>
#include <windows.h>
#pragma GCC optimize(3)
#pragma GCC target("avx,sse2,sse3,sse4,mmx")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
 
using namespace std;
 
int getvoice(int s) {
	if (s == 0) return 0;
	if (s == -1) return 262;
	if (s == -2) return 294;
	if (s == -3) return 330;
	if (s == -4) return 349;
	if (s == -5) return 392;
	if (s == -6) return 440;
	if (s == -7) return 493;
	if (s == 1) return 532;
	if (s == 2) return 578;
	if (s == 3) return 659;
	if (s == 4) return 698;
	if (s == 5) return 784;
	if (s == 6) return 880;
	if (s == 7) return 988;
	if (s == 10) return 1046;
	if (s == 20) return 1175;
	if (s == 30) return 1318;
	if (s == 40) return 1480;
	if (s == 50) return 1568;
	if (s == 60) return 1760;
	if (s == 70) return 1976;
}
 
int gettime(int s) {
	if (s == 4) return 1600;
	if (s == 3) return 1200;
	if (s == 2) return 800;
	if (s == 1) return 500;
	if (s == 10) return 750;
	if (s == -2) return 400;
	if (s == -20) return 600;
	if (s == -4) return 200;
	if (s == -40) return 300;
	if (s == -8) return 50;
	if (s == -80) return 75;
}
 
int prevoice[5] = {2, -7, 1, -6}, pretime[5] = {-4, -4, -4, -4};
int para1voice[50] = {3, 0, 0, 1, 2, 1, 3, 0, 1, 2, 1, 2, 3, -6, 1, -6, 1, -6, 1, 2, 1, -7, 0, 0, 3, 0, 0, 1, 2, 1, 3, 0, 1, 2, 1, 2, 3, -6, 1, -6, 1, -6, 1, 3, 2, -7, 0, 0}, para1time[50] = {2, 1, -4, -4, -4, -4, 2, -20, -4, -4, -4, -4, -4, -20, -4, -20, -4, -20, -4, -2, -2, 2, 1, 1, 2, 1, -4, -4, -4, -4, 2, -20, -4, -4, -4, -4, -4, -20, -4, -20, -4, -20, -4, -2, -2, 2, 1, 1}; 
int para2voice[80] = {-6, 1, 6, 6, 6, 6, 5, 6, 6, 5, 6, 5, 6, 5, 3, 3, 3, 0, 0, -6, 1, 6, 6, 6, 5, 6, 5, 7, 7, 7, 6, 7, 7, 6, 3, 3, 0, 3, 5, 3, 2, 3, 2, 3, 2, 3, 5, 3, 5, 3, 2, 3, 2, 3, 2, 0, 1, 2, 3, -6, 1, 3, 2, 3, 2, 1, 1, -6, 0, 0}, para2time[80] = {-4, -4, -2, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -4, -2, 1, 1, -2, -4, -4, -2, -4, -4, -4, -4, -4, -20, -4, -4, -4, -2, -4, -2, -4, 2, -4, -4, -4, -4, -20, -4, -20, -4, -20, -4, -4, -4, -4, -4, -20, -4, -20, -4, 1, -2, -4, -4, -2, -2, -2, -2, -20, -4, -4, -4, -2, 2, 1, -2};
int para3voice[120] = {6, 7, 10, 20, 7, 10, 10, 10, 7, 10, 20, 7, 10, 10, 10, 20, 30, 20, 30, 20, 30, 30, 20, 30, 50, 30, 6, 7, 10, 20, 7, 10, 10, 10, 7, 10, 20, 7, 10, 10, 10, 20, 30, 20, 30, 20, 30, 30, 20, 30, 50, 30, 50, 30, 50, 30, 50, 30, 50, 60, 30, 50, 50, 30, 50, 30, 50, 30, 50, 60, 30, 50, 50, 50, 30, 20, 20, 20, 10, 30, 30, 20, 20, 20, 10, 10, 6, 0, 0, 50, 50, 30, 20, 20, 20, 10, 30, 30, 20, 20, 20, 10, 10, 6, 0, 0, 0, 0}, para3time[120] = {-4, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -2, -4, -4, -2, -2, -2, -4, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -2, -4, -4, -2, -2, -2, -2, -20, -4, -20, -4, -4, -4, -4, -4, -2, -2, -20, -4, -20, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -2, -2, -4, -4, -4, -4, -2, -2, -4, -4, 2, 1, -2, -4, -4, -4, -4, -2, -2, -4, -4, -4, -4, -2, -2, -4, -4, 2, 1, 1, 1, 1}; 
int para4voice[80] = {6, 5, 6, 5, 6, 5, 6, 5, 6, 6, 5, 6, 5, 6, 5, 3, 3, 3, 0, 0, 6, 5, 6, 5, 6, 5, 6, 5, 7, 7, 7, 6, 7, 6, 3, 3, 3, 0, 0, 3, 5, 3, 2, 3, 2, 3, 2, 3, 5, 3, 5, 3, 2, 3, 2, 3, 2, 0, 1, 2, 3, 6, 10, 30, 20, 30, 20, 10, 10, 6, 0}, para4time[80] = {-4, -4, -20, -4, -4, -4, -4, -4, -2, -4, -4, -4, -4, -4, -4, -4, -20, 1, 1, -2, -4, -4, -2, -4, -4, -4, -4, -4, -20, -4, -4, -4, -4, -4, -4, -2, 1, 1, -4, -4, -4, -4, -20, -4, -20, -4, -20, -4, -4, -4, -4, -4, -20, -4, -20, -4, 1, -2, -4, -4, -2, -2, -2, -2, -20, -4, -4, -4, -2, 3, -2};
int para5voice[30] = {-6, 1, 3, 7, 7, 7, 7, 6, 5, 5, 0, 6, -6, 1, 3, 7, 7, 7, 7, 6, 5, 5, 0}, para5time[30] = {-2, -2, -2, 1, -2, -4, -4, -4, -20, 3, -2, -2, -2, -2, 1, -2, -4, -4, -4, -20, 2, -2};
 
void pre() {
	for (int i = 1; i <= 10; i++) {
		for (int j = 0; j < 4; j++) Beep(getvoice(prevoice[j]), gettime(pretime[j]));
	}
}
 
void para1() {
	for (int j = 0; j < 48; j++) Beep(getvoice(para1voice[j]), gettime(para1time[j]));
}
 
void para2() {
	for (int j = 0; j < 70; j++) Beep(getvoice(para2voice[j]), gettime(para2time[j]));
}
 
void para3() {
	for (int j = 0; j < 108; j++) Beep(getvoice(para3voice[j]), gettime(para3time[j]));
}
 
void para4() {
	for (int j = 0; j < 71; j++) Beep(getvoice(para4voice[j]), gettime(para4time[j]));
}
 
void para5() {
	for (int j = 0; j < 22; j++) Beep(getvoice(para5voice[j]), gettime(para5time[j]));
}
 
int main() {
    HWND hwnd=GetForegroundWindow();
    ShowWindow(hwnd,SW_HIDE);
	pre();
	para1();
	para2();
	para3();
	para4();
	para3();
	para5();
	para3();
	return 0;
}

