#include<bits/stdc++.h>
#include <windows.h>
#define n1 600
#define n2 1000
#define n3 1000
#define br 950
#define D 405
#define R 450
#define M 510
#define F 540
#define S 615
#define L 677
#define X 746
#define D2 792
#define S2 310
#define n4 150
#define n5 300
void b(int a,int b) {
    Beep(a,b);
}
int  main() {
    HWND hwnd=GetForegroundWindow();
    ShowWindow(hwnd,SW_HIDE);
    b(D,n1);
    b(D,n4);
    b(D,n3);
    b(S2,br+100);
    Sleep(250);
    b(M,n1);
    b(M,n4);
    b(M,n3);
    b(D,n2);
    Sleep(800);
    b(D,n5);
    b(M,n5);
    b(S,n3);
    b(S,n2);
    b(F,n5+200);
    b(M,n5-200);
    b(R,n2);
    Sleep(800);
    b(R,n5+200);
    b(M,n5-200);
    b(F,n2-100);
    b(F,n2-100);
    b(M,n2-300);
    b(R+25,n5-150);
    b(M,n2-300);
    b(D,n2);
    Sleep(400);
    b(D,n2-100);
    b(M,n5+100);
    b(R,n5+250);
    b(S2,n5+250);
    b(S2+75,n5+150);
    b(R,n5-150);
    b(D,3000);
    Sleep(2000);
}

